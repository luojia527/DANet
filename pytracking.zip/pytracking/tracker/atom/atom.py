from pytracking.tracker.base import BaseTracker
import torch.nn.functional as F
import torch.nn
import math
import time
from pytracking import dcf, fourier, TensorList, operation
from pytracking.features.preprocessing import numpy_to_torch
from pytracking.utils.plotting import show_tensor
from pytracking.libs.optimization import GaussNewtonCG, ConjugateGradient, GradientDescentL2
from .optim import ConvProblem, FactorizedConvProblem
from pytracking.features import augmentation

# ↓↓↓ Modified by Y.Xiao
import matplotlib
# matplotlib.use('TkAgg')

import matplotlib.pyplot as plt
import matplotlib.pylab as pylab

import requests
from io import BytesIO

# this makes our figures bigger
#pylab.rcParams['figure.figsize'] = 20, 12

#from maskrcnn_benchmark.config import cfg

import pytracking.yolact.eval as ev

from pytracking.tracker.modules.sample_generator import *
from pytracking.tracker.modules.model import *
from pytracking.tracker.modules.actor import *
from pytracking.tracker.modules.region_to_bbox import *
from pytracking.tracker.tracking.data_prov import *
from pytracking.tracker.tracking.bbreg import *
from pytracking.tracker.tracking.options import *
from pytracking.tracker.tracking.gen_config import *

import torch.optim as optim
from torch.autograd import Variable
from PIL import Image, ImageFilter, ImageOps
import numpy as np
import cv2

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

np.random.seed(123)
torch.manual_seed(456)
torch.cuda.manual_seed(789)
torch.backends.cudnn.enabled = False
# ↑↑↑ Modified by Y.Xiao

class ATOM(BaseTracker):

    def initialize_features(self):
        if not getattr(self, 'features_initialized', False):
            self.params.features.initialize()
        self.features_initialized = True


    def initialize(self, image, info: dict) -> dict:
        state = info['init_bbox']

        # Initialize some stuff
        self.frame_num = 1   # Modified by Y.Xiao default is 1

        if not hasattr(self.params, 'device'):
            self.params.device = 'cuda' if self.params.use_gpu else 'cpu'
        
        # Initialize features
        self.initialize_features()

        # Check if image is color
        self.params.features.set_is_color(image.shape[2] == 3)

        # Get feature specific params
        self.fparams = self.params.features.get_fparams('feature_params')

        tic = time.time()

        # Get position and size
        self.pos = torch.Tensor([state[1] + (state[3] - 1)/2, state[0] + (state[2] - 1)/2])
        self.target_sz = torch.Tensor([state[3], state[2]])

        # Set search area
        self.target_scale = 1.0
        search_area = torch.prod(self.target_sz * self.params.search_area_scale).item()
        if search_area > self.params.max_image_sample_size:
            self.target_scale =  math.sqrt(search_area / self.params.max_image_sample_size)
        elif search_area < self.params.min_image_sample_size:
            self.target_scale =  math.sqrt(search_area / self.params.min_image_sample_size)

        # Check if IoUNet is used
        self.use_iou_net = getattr(self.params, 'use_iou_net', True)

        # Target size in base scale
        self.base_target_sz = self.target_sz / self.target_scale

        # Use odd square search area and set sizes
        feat_max_stride = max(self.params.features.stride())
        if getattr(self.params, 'search_area_shape', 'square') == 'square':
            self.img_sample_sz = torch.round(torch.sqrt(torch.prod(self.base_target_sz * self.params.search_area_scale))) * torch.ones(2)
        elif self.params.search_area_shape == 'initrect':
            self.img_sample_sz = torch.round(self.base_target_sz * self.params.search_area_scale)
        else:
            raise ValueError('Unknown search area shape')
        if self.params.feature_size_odd:
            self.img_sample_sz += feat_max_stride - self.img_sample_sz % (2 * feat_max_stride)
        else:
            self.img_sample_sz += feat_max_stride - (self.img_sample_sz + feat_max_stride) % (2 * feat_max_stride)

        # Set sizes
        self.img_support_sz = self.img_sample_sz
        self.feature_sz = self.params.features.size(self.img_sample_sz)
        self.output_sz = self.params.score_upsample_factor * self.img_support_sz  # Interpolated size of the output
        self.kernel_size = self.fparams.attribute('kernel_size')

        self.iou_img_sample_sz = self.img_sample_sz

        # Optimization options
        self.params.precond_learning_rate = self.fparams.attribute('learning_rate')
        if self.params.CG_forgetting_rate is None or max(self.params.precond_learning_rate) >= 1:
            self.params.direction_forget_factor = 0
        else:
            self.params.direction_forget_factor = (1 - max(self.params.precond_learning_rate))**self.params.CG_forgetting_rate

        self.output_window = None
        if getattr(self.params, 'window_output', False):
            if getattr(self.params, 'use_clipped_window', False):
                self.output_window = dcf.hann2d_clipped(self.output_sz.long(), self.output_sz.long()*self.params.effective_search_area / self.params.search_area_scale, centered=False).to(self.params.device)
            else:
                self.output_window = dcf.hann2d(self.output_sz.long(), centered=False).to(self.params.device)

        # Initialize some learning things
        self.init_learning()

        # Convert image
        im = numpy_to_torch(image)
        self.im = im    # For debugging only

        # Setup scale bounds
        self.image_sz = torch.Tensor([im.shape[2], im.shape[3]])
        self.min_scale_factor = torch.max(10 / self.base_target_sz)
        self.max_scale_factor = torch.min(self.image_sz / self.base_target_sz)

        # Extract and transform sample
        x = self.generate_init_samples(im)

        # Initialize iounet
        if self.use_iou_net:
            self.init_iou_net()

        # Initialize projection matrix
        self.init_projection_matrix(x)

        # Transform to get the training sample
        train_x = self.preprocess_sample(x)

        # Generate label function
        init_y = self.init_label_function(train_x)

        # Init memory
        self.init_memory(train_x)

        # Init optimizer and do initial optimization
        self.init_optimization(train_x, init_y)

        self.pos_iounet = self.pos.clone()


        # ↓↓↓ Add ACT init - by Y.Xiao
        # define the control variable for display debug image
        # ev.test()
        # ev.call_yolact_by_image_path('/home/ubuntu/user_space/dev/pytracking-study/pytracking/yolact/weights/yolact_im700_54_800000.pth',
        #                             0.15, 15, '/home/ubuntu/user_space/dev/pytracking-study/pytracking/yolact/test2.jpg',
        #               '/home/ubuntu/user_space/dev/pytracking-study/pytracking/yolact/output_image.png')

        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)

        self.need_debug_image = False

        image_act = Image.fromarray(image, mode='RGB')

        # Define an array for saving pos_ variable
        self.pos_data_from_rl = []

        # the variable state here has the same meaning with ACT tracker
        self.rate = state[2] / state[3]
        self.target_bbox_act = np.array(state)
        self.target_bbox_init_act = np.array(state)
        self.bbreg_bbox_act = self.target_bbox_act
        self.result_act = {}
        self.result_act_bb = {}

        self.result_act[0] = self.target_bbox_act
        self.result_act_bb[0] = self.target_bbox_act

        self.success = 1

        # Init model
        self.model_act_mdnet = MDNet(opts_act['model_path'])
        self.actor_act = Actor_act(opts_act['actor_path'])

        if opts_act['use_gpu']:
            self.model_act_mdnet = self.model_act_mdnet.cuda()
            self.actor_act = self.actor_act.cuda()
        self.model_act_mdnet.set_learnable_params(opts_act['ft_layers'])

        # Init criterion and optimizer
        self.criterion = BinaryLoss()
        self.init_optimizer = self.set_optimizer(self.model_act_mdnet, opts_act['lr_init'])
        self.update_optimizer = self.set_optimizer(self.model_act_mdnet, opts_act['lr_update'])

        # Train bbox regressor
        bbreg_examples_act = gen_samples(SampleGenerator('uniform', image_act.size, 0.3, 1.5, 1.1),
                                     self.target_bbox_act, opts_act['n_bbreg'], opts_act['overlap_bbreg'], opts_act['scale_bbreg'])
        bbreg_feats_act = self.forward_samples(self.model_act_mdnet, image_act, bbreg_examples_act)
        self.bbreg_act = BBRegressor(image_act.size)
        self.bbreg_act.train(bbreg_feats_act, bbreg_examples_act, self.target_bbox_act)

        # Draw pos/neg samples
        pos_examples = gen_samples(SampleGenerator('gaussian', image_act.size, 0.1, 1.2),
                                   self.target_bbox_act, opts_act['n_pos_init'], opts_act['overlap_pos_init'])

        neg_examples = np.concatenate([
            gen_samples(SampleGenerator('uniform', image_act.size, 1, 2, 1.1),
                        self.target_bbox_act, opts_act['n_neg_init'] // 2, opts_act['overlap_neg_init']),
            gen_samples(SampleGenerator('whole', image_act.size, 0, 1.2, 1.1),
                        self.target_bbox_act, opts_act['n_neg_init'] // 2, opts_act['overlap_neg_init'])])
        neg_examples = np.random.permutation(neg_examples)

        # Extract pos/neg features
        pos_feats = self.forward_samples(self.model_act_mdnet, image_act, pos_examples)
        neg_feats = self.forward_samples(self.model_act_mdnet, image_act, neg_examples)

        # Initial training
        self.train_act(self.model_act_mdnet, self.criterion, self.init_optimizer, pos_feats, neg_feats, opts_act['maxiter_init'])
        self.deta_flag, self.out_flag_first = self.init_actor(self.actor_act, image_act, self.target_bbox_act)

        # Init sample generators
        self.init_generator = SampleGenerator('gaussian', image_act.size, opts_act['trans_f'], 1, valid=False)
        self.sample_generator = SampleGenerator('gaussian', image_act.size, opts_act['trans_f'], opts_act['scale_f'], valid=False)
        self.pos_generator = SampleGenerator('gaussian', image_act.size, 0.1, 1.2)
        self.neg_generator = SampleGenerator('uniform', image_act.size, 1.5, 1.2)

        # Init pos/neg features for update
        self.pos_feats_all = [pos_feats[:opts_act['n_pos_update']]]
        self.neg_feats_all = [neg_feats[:opts_act['n_neg_update']]]
        self.data_frame = [0]

        pos_score = self.forward_samples(self.model_act_mdnet, image_act, self.target_bbox_act.reshape([1, 4]), out_layer='fc6')
        self.img_learn = [image_act]
        self.pos_learn = [self.target_bbox_init_act]
        self.score_pos = [pos_score.cpu().numpy()[0][1]]
        self.frame_learn = [0]
        self.pf_frame = []

        self.update_lenth = 10
        self.spf_total = 0

        self.imageVar_first = cv2.Laplacian(self.crop_image_blur(np.array(image), self.target_bbox_act), cv2.CV_64F).var()
        self.detetion = 0

        # call yolact
        self.use_spatial_attention = True
        self.seg_iou_thresh = 0.3
        self.mask_area_max = 2.25
        self.mask_area_min = 0.25
        self.mask_conf_thresh = 0.30
        self.mask_rect_scale = 1.5
        self.attention_strength = 0.25#0.75

        # Union location
        self.threshold_act_atom = 6

        if self.use_spatial_attention:
            trained_model = './yolact/weights/yolact_im700_54_800000.pth'
            score_threshold = 0.15
            top_k = 3
            crop_param = [0, 0, 0, 0]
            crop_param[0] = state[0] - 65
            crop_param[1] = state[1] - 65
            crop_param[2] = state[0] + state[2] + 65
            crop_param[3] = state[1] + state[3] + 65
            image_pil = Image.fromarray(image)
            image_pil_cropped = image_pil.crop(crop_param)
            image_pil_cropped.save('cropped.jpg')
            np_im = np.array(image_pil_cropped)
            img_crop_g, out_flag = self.crop_image_actor_2(image, state)

            # structure of t: t[0]-classes  t[1]-scores  t[2]-baxes  t[3]-masks
            self.yolact = ev.load_yolact(trained_model, score_threshold, top_k)
            t = ev.evaluate_for_image_object(self.yolact, img_crop_g)
            mask_np = np.ones([int(self.target_bbox_act[3]*self.mask_rect_scale), int(self.target_bbox_act[2]*self.mask_rect_scale)])

            if t[0].shape[0] == 0:
                print('Target segmentation failed in the initial frame and will be disabled for the sequence.')
                self.initial_mask_success = False
            else:
                ious = [self.calculate_seg_iou(seg_box) for seg_box in t[2]]
                # ious = [mask.sum().cpu().detach().numpy() for mask in t[3]]
                if max(ious) >= self.seg_iou_thresh and \
                        t[1][ious.index(max(ious))] > self.mask_conf_thresh:  # size within [0.5, 2.25] and confidence over 50%
                    self.initial_mask_success = True
                    self.target_class = t[0][ious.index(max(ious))]  # target class is set to mask with max iou
                    mask_np = t[3][ious.index(max(ious))].cpu().detach().numpy()
                else:
                    print('Target segmentation failed in the initial frame and will be disabled for the sequence.')
                    self.initial_mask_success = False
            epane_padding = 4
            crop_padding = 1
            self.attention_map_resize = 2
            self.spatial_attention_map = self.get_spatial_attention(mask_np, epane_padding, crop_padding)

        self.target_bbox_history = []
        # ↑↑↑ Add and modify ACT init - by Y.Xiao

        # out = {'time': time.time() - tic}
        out = {'time': 100}
        return out

    def calculate_seg_iou(self, seg):
        iou = 0
        x, y, w, h = np.array(self.target_bbox_act, dtype='float32')

        half_w, half_h = w / 2, h / 2
        center_x, center_y = x + half_w, y + half_h

        min_x = int(center_x - 1.5 * w + 0.5)
        min_y = int(center_y - 1.5 * h + 0.5)
        seg_bbox = np.array([seg[0] + min_x, seg[1] + min_y, seg[2] - seg[0], seg[3] - seg[1]])

        xA = max(self.target_bbox_act[0], seg_bbox[0])
        yA = max(self.target_bbox_act[1], seg_bbox[1])
        xB = min(self.target_bbox_act[0] + self.target_bbox_act[2], seg_bbox[0] + seg_bbox[2])
        yB = min(self.target_bbox_act[1] + self.target_bbox_act[3], seg_bbox[1] + seg_bbox[3])

        if xA < xB and yA < yB:
            interArea = (xB - xA) * (yB - yA)
            boxAArea = self.target_bbox_act[2] * self.target_bbox_act[3]
            boxBArea = seg_bbox[2] * seg_bbox[3]
            iou = interArea / float(boxAArea + boxBArea - interArea)
        else:
            iou = 0

        return iou

    # The higher score, the better
    def calculate_scale_similarity(self, seg_class, seg_bounding_box):
        result = - abs(self.target_bbox_act[2] - seg_bounding_box[2] + seg_bounding_box[0]) - \
                 abs(self.target_bbox_act[3] - seg_bounding_box[3] + seg_bounding_box[1])
        # if self.target_class != seg_class:
        #     result = -1000

        return result

    def select_mask_sim_conf(self, sim_conf):
        index = 0
        sorted(sim_conf, key=lambda isc: isc[2])
        max_conf = sim_conf[-1][2]
        max_sim = sim_conf[-1][1]
        for i, sim, conf in sim_conf:
            if max_conf - conf < 0.10 and sim > max_sim:
                index = i
                max_sim = sim

        return index

    def call_a(self):
        print ('call a')
        return 100

    def init_optimization(self, train_x, init_y):
        # Initialize filter
        filter_init_method = getattr(self.params, 'filter_init_method', 'zeros')
        self.filter = TensorList(
            [x.new_zeros(1, cdim, sz[0], sz[1]) for x, cdim, sz in zip(train_x, self.compressed_dim, self.kernel_size)])
        if filter_init_method == 'zeros':
            pass
        elif filter_init_method == 'randn':
            for f in self.filter:
                f.normal_(0, 1/f.numel())
        else:
            raise ValueError('Unknown "filter_init_method"')

        # Get parameters
        self.params.update_projection_matrix = getattr(self.params, 'update_projection_matrix', True) and self.params.use_projection_matrix
        optimizer = getattr(self.params, 'optimizer', 'GaussNewtonCG')

        # Setup factorized joint optimization
        if self.params.update_projection_matrix:
            self.joint_problem = FactorizedConvProblem(self.init_training_samples, init_y, self.filter_reg,
                                                       self.fparams.attribute('projection_reg'), self.params, self.init_sample_weights,
                                                       self.projection_activation, self.response_activation)

            # Variable containing both filter and projection matrix
            joint_var = self.filter.concat(self.projection_matrix)

            # Initialize optimizer
            analyze_convergence = getattr(self.params, 'analyze_convergence', False)
            if optimizer == 'GaussNewtonCG':
                self.joint_optimizer = GaussNewtonCG(self.joint_problem, joint_var, debug=(self.params.debug >= 1),
                                                     plotting=(self.params.debug >= 3), analyze=analyze_convergence,
                                                     visdom=self.visdom)
            elif optimizer == 'GradientDescentL2':
                self.joint_optimizer = GradientDescentL2(self.joint_problem, joint_var, self.params.optimizer_step_length, self.params.optimizer_momentum, plotting=(self.params.debug >= 3), debug=(self.params.debug >= 1),
                                                         visdom=self.visdom)

            # Do joint optimization
            if isinstance(self.params.init_CG_iter, (list, tuple)):
                self.joint_optimizer.run(self.params.init_CG_iter)
            else:
                self.joint_optimizer.run(self.params.init_CG_iter // self.params.init_GN_iter, self.params.init_GN_iter)

            if analyze_convergence:
                opt_name = 'CG' if getattr(self.params, 'CG_optimizer', True) else 'GD'
                for val_name, values in zip(['loss', 'gradient'], [self.joint_optimizer.losses, self.joint_optimizer.gradient_mags]):
                    val_str = ' '.join(['{:.8e}'.format(v.item()) for v in values])
                    file_name = '{}_{}.txt'.format(opt_name, val_name)
                    with open(file_name, 'a') as f:
                        f.write(val_str + '\n')
                raise RuntimeError('Exiting')

        # Re-project samples with the new projection matrix
        compressed_samples = self.project_sample(self.init_training_samples, self.projection_matrix)
        for train_samp, init_samp in zip(self.training_samples, compressed_samples):
            train_samp[:init_samp.shape[0],...] = init_samp

        self.hinge_mask = None

        # Initialize optimizer
        self.conv_problem = ConvProblem(self.training_samples, self.y, self.filter_reg, self.sample_weights, self.response_activation)

        if optimizer == 'GaussNewtonCG':
            self.filter_optimizer = ConjugateGradient(self.conv_problem, self.filter, fletcher_reeves=self.params.fletcher_reeves,
                                                      direction_forget_factor=self.params.direction_forget_factor, debug=(self.params.debug>=1),
                                                      plotting=(self.params.debug>=3), visdom=self.visdom)
        elif optimizer == 'GradientDescentL2':
            self.filter_optimizer = GradientDescentL2(self.conv_problem, self.filter, self.params.optimizer_step_length,
                                                      self.params.optimizer_momentum, debug=(self.params.debug >= 1),
                                                      plotting=(self.params.debug>=3), visdom=self.visdom)

        # Transfer losses from previous optimization
        if self.params.update_projection_matrix:
            self.filter_optimizer.residuals = self.joint_optimizer.residuals
            self.filter_optimizer.losses = self.joint_optimizer.losses

        if not self.params.update_projection_matrix:
            self.filter_optimizer.run(self.params.init_CG_iter)

        # Post optimization
        self.filter_optimizer.run(self.params.post_init_CG_iter)

        # Free memory
        del self.init_training_samples
        if self.params.use_projection_matrix:
            del self.joint_problem, self.joint_optimizer


    def track(self, image) -> dict:

        # ↓↓↓ Add ACT part - by Y.Xiao
        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)

        self.image_for_display = image.copy()

        if self.use_spatial_attention:
            crop_param = [0, 0, 0, 0]
            crop_param[0] = self.target_bbox_act[0] - 65
            crop_param[1] = self.target_bbox_act[1] - 65
            crop_param[2] = self.target_bbox_act[0] + self.target_bbox_act[2] + 65
            crop_param[3] = self.target_bbox_act[1] + self.target_bbox_act[3] + 65
            image_pil = Image.fromarray(image)
            image_pil_cropped = image_pil.crop(crop_param)
            image_pil_cropped.save('cropped.jpg')
            np_im = np.array(image_pil_cropped)
            img_crop_g, out_flag = self.crop_image_actor_2(image, self.target_bbox_act)

            # structure of t: t[0]-classes  t[1]-scores  t[2]-baxes  t[3]-masks
            t = ev.evaluate_for_image_object(self.yolact, img_crop_g)
            # t = ev.call_yolact_by_image_object(trained_model, score_threshold, top_k, img_crop_g)
            mask_np = np.ones([int(self.target_bbox_act[3] * self.mask_rect_scale),
                               int(self.target_bbox_act[2] * self.mask_rect_scale)])
            area_ubound = int(self.target_bbox_act[2] * self.target_bbox_act[3] * self.mask_area_max)
            area_lbound = int(self.target_bbox_act[2] * self.target_bbox_act[3] * self.mask_area_min)
            rec_mask = False
            if not self.initial_mask_success:
                rec_mask = True
            elif t[3].shape[0] == 0:
                rec_mask = True
            else:
                sim_conf = [(i, self.calculate_scale_similarity(t[0][i], t[2][i]), t[1][i]) for i in range(t[3].shape[0]) if \
                            t[0][i] == self.target_class and \
                            t[1][i] > self.mask_conf_thresh and \
                            area_lbound <= int(t[3][i].cpu().detach().numpy().sum()) <= area_ubound]
                if len(sim_conf) != 0:
                    best_mask = self.select_mask_sim_conf(sim_conf)
                    mask_np = t[3][best_mask].cpu().detach().numpy()
                else:
                    rec_mask = True
            # elif t[3].shape[0] == 1:
            #     mask_np = t[3][0].cpu().detach().numpy()
            #     seg_box_size = t[2][0]
            # elif t[3].shape[0] == 2:
            #     simi_0 = self.calcuate_scale_similarity(t[0][0], t[2][0])
            #     simi_1 = self.calcuate_scale_similarity(t[0][1], t[2][1])
            #
            #     c = [simi_0, simi_1]
            #     index_c = c.index(max(c))
            #     mask_np = t[3][index_c].cpu().detach().numpy()
            #     seg_box_size = t[2][index_c]
            #
            # else:
            #     simi_0 = self.calcuate_scale_similarity(t[0][0], t[2][0])
            #     simi_1 = self.calcuate_scale_similarity(t[0][1], t[2][1])
            #     simi_2 = self.calcuate_scale_similarity(t[0][2], t[2][2])
            #
            #     c = [simi_0, simi_1, simi_2]
            #     index_c = c.index(max(c))
            #     mask_np = t[3][index_c].cpu().detach().numpy()
            #     seg_box_size = t[2][index_c]

            if int(mask_np.sum()) == mask_np.shape[0] * mask_np.shape[1] and not rec_mask:  # all 1
                mask_np = np.ones([int(self.target_bbox_act[3]*self.mask_rect_scale), int(self.target_bbox_act[2]*self.mask_rect_scale)])
                rec_mask = True
            if int(mask_np.sum()) < area_lbound or \
                    int(mask_np.sum()) > area_ubound:  # overlap < 50%
                mask_np = np.ones([int(self.target_bbox_act[3]*self.mask_rect_scale), int(self.target_bbox_act[2]*self.mask_rect_scale)])
                rec_mask = True

            mask_copy = mask_np.copy()

            # prepare display image
            x, y, w, h = np.array(self.target_bbox_act, dtype='float32')

            half_w, half_h = w / 2, h / 2
            center_x, center_y = x + half_w, y + half_h

            img_h, img_w, _ = self.image_for_display.shape

            min_x = int(center_x - 1.5 * w + 0.5)
            min_y = int(center_y - 1.5 * h + 0.5)
            max_x = int(center_x + 1.5 * w + 0.5)
            max_y = int(center_y + 1.5 * h + 0.5)

            if rec_mask: # rectangle mask
                min_x = int(center_x - self.mask_rect_scale / 2 * w + 0.5)
                min_y = int(center_y - self.mask_rect_scale / 2 * h + 0.5)
                max_x = min_x + int(self.target_bbox_act[2]*self.mask_rect_scale)
                max_y = min_y + int(self.target_bbox_act[3]*self.mask_rect_scale)

            if min_x < 0:
                mask_copy = mask_copy[:,0-min_x:]
            if min_y < 0:
                mask_copy = mask_copy[0-min_y:,:]
            min_x = max(0, min_x)
            min_y = max(0, min_y)
            if max_x > img_w:
                mask_copy = mask_copy[:,:img_w - min_x]
            if max_y > img_h:
                mask_copy = mask_copy[:img_h - min_y, :]
            max_x = min(img_w,max_x)
            max_y = min(img_h,max_y)

            mask_copy = 1 - mask_copy

            mask_R = mask_copy.copy()
            mask_R[mask_R<.5] = 13/255
            mask_G = mask_copy.copy()
            mask_G[mask_G<.5] = 144/255
            mask_B = mask_copy.copy()
            mask_B[mask_B<.5] = 191/255

            self.image_for_display[min_y:max_y, min_x:max_x, 0] = (
                    self.image_for_display[min_y:max_y, min_x:max_x, 0].astype('float') * mask_R).astype('int')

            self.image_for_display[min_y:max_y, min_x:max_x, 1] = (
                    self.image_for_display[min_y:max_y,min_x:max_x,1].astype('float') * mask_G).astype('int')

            self.image_for_display[min_y:max_y, min_x:max_x, 2] = (
                        self.image_for_display[min_y:max_y, min_x:max_x, 2].astype('float') * mask_B).astype('int')
            # display image preparation end

            # draw poly lines
            mask = (1 - mask_copy).astype(np.uint8)
            contours, _ = cv2.findContours(mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
            cnt_area = [cv2.contourArea(cnt) for cnt in contours]
            if len(cnt_area) != 0 and np.max(cnt_area) > 100:
                contour = contours[np.argmax(cnt_area)]
                polygon = contour.reshape(-1, 2)
                ellipse = cv2.fitEllipse(polygon)
                new_ellipse = (ellipse[0], (0.9 * ellipse[1][0], 0.9 * ellipse[1][1]), ellipse[-1])
                ellipseBox = cv2.boxPoints(new_ellipse).flatten()

                ellipseBox[::2] += min_x
                ellipseBox[1::2] += min_y
                pred_bbox = ellipseBox.tolist()
                # Note: comment the line below to disable poly lines output. Modify the last two args to change color and weight
                cv2.polylines(self.image_for_display, [np.array(pred_bbox, np.int).reshape((-1, 1, 2))], True, (0, 255, 255), 1)
            # poly lines end

            epane_padding = 4
            crop_padding = 1
            self.attention_map_resize = 2
            self.spatial_attention_map = self.get_spatial_attention(mask_np, epane_padding, crop_padding)

        if self.use_spatial_attention:
            # Estimate target bbox
            # pre-process the image, letting it be with spatial attention

            # padding the spatial attention
            # resize the spatial attention
            # self.target_bbox_act[2] is width
            # self.target_bbox_act[3] is height
            if self.target_bbox_act[2] >= self.target_bbox_act[3]:
                width = self.spatial_attention_map.shape[1]
                height = int(
                    np.around(self.spatial_attention_map.shape[0] * (self.target_bbox_act[3] / self.target_bbox_act[2]),
                              decimals=0))
            else:
                height = self.spatial_attention_map.shape[0]
                width = int(
                    np.around(self.spatial_attention_map.shape[1] * (self.target_bbox_act[2] / self.target_bbox_act[3]),
                              decimals=0))

            sp_att_pil = Image.fromarray(self.spatial_attention_map).resize((width, height))
            if self.need_debug_image:
                sp_att_pil.show()

            # Crop the mask pillow image
            map_width = sp_att_pil.size[0]
            map_height = sp_att_pil.size[1]
            target_width = self.target_bbox_act[2]
            target_height = self.target_bbox_act[3]
            left = int(np.round((map_width - target_width) * 0.5))
            up = int(np.round((map_height - target_height) * 0.5))
            right = left + target_width
            bottom = up + target_height
            sp_att_pil = sp_att_pil.crop((left, up, right, bottom))

            # expand the spatial attention map to match the size of the total frame
            # get the center coordinate
            co_y = self.pos[0].numpy()
            co_x = self.pos[1].numpy()

            # get the width and height of spatial attention map
            att_width = int(np.round(sp_att_pil.size[0] * self.attention_map_resize))
            att_height = int(np.round(sp_att_pil.size[1] * self.attention_map_resize))

            # resize the attention map to make it bigger
            sp_att_pil = sp_att_pil.resize((att_width, att_height))

            # calculate the padding value
            frame_width = image.shape[1]
            frame_height = image.shape[0]
            top_pad = int(np.round(co_y - 0.5 * att_height))
            bottom_pad = int(np.round(frame_height - co_y - 0.5 * att_height))
            left_pad = int(np.round(co_x - 0.5 * att_width))
            right_pad = int(np.round(frame_width - co_x - 0.5 * att_width))

            # avoid the padding value which is smaller than 0
            if top_pad < 0:
                top_pad = 0
            if bottom_pad < 0:
                bottom_pad = 0
            if left_pad < 0:
                left_pad = 0
            if right_pad < 0:
                right_pad = 0

            if (top_pad + att_height + bottom_pad) > frame_height:
                top_pad = top_pad - ((top_pad + att_height + bottom_pad) - frame_height)
            if (left_pad + att_width + right_pad) > frame_width:
                left_pad = left_pad - ((left_pad + att_width + right_pad) - frame_width)

            # build attention map padding parameters
            att_padding = (left_pad, top_pad, right_pad, bottom_pad)

            # expand the spatial attention map to fit the whole frame
            sp_att_pil = ImageOps.expand(sp_att_pil, att_padding)
            if self.need_debug_image:
                sp_att_pil.show()

            # apply the spatial attention on the total frame image,
            # and then modify the image
            sp_att_pil_np = np.array(sp_att_pil)

            # find pure black pixel indexes
            index_black = np.where(sp_att_pil_np == 0)

            # modify the total frame image
            image[index_black] = (self.attention_strength * image[index_black]).astype('int')

        self.image_for_display = image.copy()
        image_pil = Image.fromarray(image, mode='RGB')
        if self.imageVar_first > 200:
            self.imageVar = cv2.Laplacian(self.crop_image_blur(np.array(image_pil), self.target_bbox_act), cv2.CV_64F).var()
        else:
            self.imageVar = 200

        img_g, img_l, out_flag = self.getbatch_actor(np.array(image_pil), np.array(self.target_bbox_act).reshape([1, 4]))
        deta_pos = self.actor_act(img_l, img_g)
        deta_pos = deta_pos.data.clone().cpu().numpy()

        if deta_pos[:, 2] > 0.05 or deta_pos[:, 2] < -0.05:
            deta_pos[:, 2] = 0
        if self.deta_flag or (out_flag and not self.out_flag_first):
            deta_pos[:, 2] = 0
        if len(self.pf_frame) and self.frame_num == (self.pf_frame[-1] + 1):
            deta_pos[:, 2] = 0

        pos_ = np.round(self.move_crop(self.target_bbox_act, deta_pos, (image_pil.size[1], image_pil.size[0]), self.rate))

        # translation_vec_2 = self.move_crop_2(self.target_bbox_act, deta_pos, (image_pil.size[1], image_pil.size[0]),
        #                                    self.rate)

        # save pos_ bariable into array
        self.pos_data_from_rl.append(pos_)

        r = self.forward_samples(self.model_act_mdnet, image_pil, np.array(pos_).reshape([1, 4]), out_layer='fc6')
        r = r.cpu().numpy()

        # print("Frame %d, Previous (%d,%d,%d,%d), Predicted (%d,%d,%d,%d), Score %.3f" % \
        #     (self.frame_num, self.target_bbox_act[0], self.target_bbox_act[1], self.target_bbox_act[2], self.target_bbox_act[3],
        #      pos_[0], pos_[1], pos_[2], pos_[3], r[0][1]))
        # print('self.target_bbox_act = ')
        # print(self.target_bbox_act)
        # print('pos_ =')
        # print(pos_)
        # print('r = ')
        # print(r)

        if r[0][1] > 0 and self.imageVar > 100:
            target_bbox = pos_
            bbreg_samples = pos_[None, :]
            bbreg_feats = self.forward_samples(self.model_act_mdnet, image_pil, bbreg_samples)
            bbreg_samples = self.bbreg_act.predict(bbreg_feats, bbreg_samples)
            self.bbreg_bbox_act = bbreg_samples.mean(axis=0)
            # self.bbreg_bbox_act = pos_
            self.success = 1
            if not out_flag:
                # fin_score = r[0][1]
                self.img_learn.append(image_pil)
                self.pos_learn.append(target_bbox)
                # self.score_pos.append(fin_score)
                self.frame_learn.append(self.frame_num)
                while len(self.img_learn) > self.update_lenth * 2:
                    del self.img_learn[0]
                    del self.pos_learn[0]
                    # del self.score_pos[0]
                    del self.frame_learn[0]
            self.result_act[self.frame_num] = target_bbox
            self.result_act_bb[self.frame_num] = self.bbreg_bbox_act
        # elif self.imageVar > 100 and not (len(self.pf_frame) and self.frame_num == (self.pf_frame[-1] + 1)):
        #     # Estimate target bbox again
        #     img_g, img_l, out_flag = self.getbatch_actor(np.array(image_pil),
        #                                                  np.array(pos_).reshape([1, 4]))
        #     deta_pos = self.actor_act(img_l, img_g)
        #     deta_pos = deta_pos.data.clone().cpu().numpy()
        #
        #     if deta_pos[:, 2] > 0.05 or deta_pos[:, 2] < -0.05:
        #         deta_pos[:, 2] = 0
        #     if self.deta_flag or (out_flag and not self.out_flag_first):
        #         deta_pos[:, 2] = 0
        #
        #     pos_ = np.round(
        #         self.move_crop(pos_, deta_pos, (image_pil.size[1], image_pil.size[0]), self.rate))
        #     r = self.forward_samples(self.model_act_mdnet, image_pil, np.array(pos_).reshape([1, 4]), out_layer='fc6')
        #     r = r.cpu().numpy()
        #
        #     if r[0][1] > 1:
        #         target_bbox = pos_
        #         bbreg_samples = pos_[None, :]
        #         bbreg_feats = self.forward_samples(self.model_act_mdnet, image_pil, bbreg_samples)
        #         bbreg_samples = self.bbreg_act.predict(bbreg_feats, bbreg_samples)
        #         self.bbreg_bbox_act = bbreg_samples.mean(axis=0)
        #         self.success = 1
        #         if not out_flag:
        #             self.fin_score = r[0][1]
        #             self.img_learn.append(image_pil)
        #             self.pos_learn.append(target_bbox)
        #             self.score_pos.append(self.fin_score)
        #             self.frame_learn.append(self.frame_num)
        #             while len(self.img_learn) > self.update_lenth * 2:
        #                 del self.img_learn[0]
        #                 del self.pos_learn[0]
        #                 del self.score_pos[0]
        #                 del self.frame_learn[0]
        #         self.result_act[self.frame_num] = target_bbox
        #         self.result_act_bb[self.frame_num] = self.bbreg_bbox_act
        # if not (r[0][1] > 0 and self.imageVar > 100):
        else:
            # print('++++++++++++++  r < 0  +++++++++++++++')
            # print(self.frame_num)
            self.detetion += 1
            if len(self.pf_frame) == 0:
                self.pf_frame = [self.frame_num]
            else:
                self.pf_frame.append(self.frame_num)

            if (len(self.frame_learn) == self.update_lenth*2 and self.data_frame[-1] not in self.frame_learn ) or self.data_frame[-1] == 0:
                for num in range(max(0, self.img_learn.__len__() - self.update_lenth), self.img_learn.__len__()):
                    if self.frame_learn[num] not in self.data_frame:
                        gt_ = self.pos_learn[num]
                        image_ = self.img_learn[num]
                        pos_examples = np.round(gen_samples(self.pos_generator, gt_,
                                                            opts_act['n_pos_update'],
                                                            opts_act['overlap_pos_update']))
                        neg_examples = np.round(gen_samples(self.neg_generator, gt_,
                                                            opts_act['n_neg_update'],
                                                            opts_act['overlap_neg_update']))
                        pos_feats_ = self.forward_samples(self.model_act_mdnet, image_, pos_examples)
                        neg_feats_ = self.forward_samples(self.model_act_mdnet, image_, neg_examples)

                        self.pos_feats_all.append(pos_feats_)
                        self.neg_feats_all.append(neg_feats_)
                        self.data_frame.append(self.frame_learn[num])
                        if len(self.pos_feats_all) > 10:
                            del self.pos_feats_all[0]
                            del self.neg_feats_all[0]
                            del self.data_frame[0]
                    else:
                        pos_feats_ = self.pos_feats_all[self.data_frame.index(self.frame_learn[num])]
                        neg_feats_ = self.neg_feats_all[self.data_frame.index(self.frame_learn[num])]

                    if num == max(0, self.img_learn.__len__() - self.update_lenth):
                        pos_feats = pos_feats_
                        neg_feats = neg_feats_

                    else:
                        pos_feats = torch.cat([pos_feats, pos_feats_], 0)
                        neg_feats = torch.cat([neg_feats, neg_feats_], 0)

                # print('------------------- READY TO TRAIN ---------------------')
                # print(self.frame_num)
                self.train_act(self.model_act_mdnet, self.criterion, self.update_optimizer, pos_feats, neg_feats, opts_act['maxiter_update'])

            if self.success:
                self.sample_generator.set_trans_f(opts_act['trans_f'])
            else:
                self.sample_generator.set_trans_f(opts_act['trans_f_expand'])

            if self.imageVar < 100:
                samples = gen_samples(self.init_generator, self.target_bbox_act, opts_act['n_samples'])
            else:
                samples = gen_samples(self.sample_generator, self.target_bbox_act, opts_act['n_samples'])

            if self.frame_num < 20 or out_flag or ((self.target_bbox_init_act[2] * self.target_bbox_init_act[3]) > 1000 and (self.target_bbox_act[2] * self.target_bbox_act[3] / (self.target_bbox_init_act[2] * self.target_bbox_init_act[3]) > 2.5 or self.target_bbox_act[2] * self.target_bbox_act[3] / (self.target_bbox_init_act[2] * self.target_bbox_init_act[3]) < 0.4)):

                self.sample_generator.set_trans_f(opts_act['trans_f_expand'])
                samples_ = np.round(gen_samples(self.sample_generator, np.hstack([self.target_bbox_act[0:2] + self.target_bbox_act[2:4] / 2 - self.target_bbox_init_act[2:4] / 2, self.target_bbox_init_act[2:4]]), opts_act['n_samples']))
                samples = np.vstack([samples, samples_])

            sample_scores = self.forward_samples(self.model_act_mdnet, image_pil, samples, out_layer='fc6')
            top_scores, top_idx = sample_scores[:, 1].topk(5)
            top_idx = top_idx.cpu().numpy()
            target_score = top_scores.mean()
            target_bbox = samples[top_idx].mean(axis=0)
            self.success = target_score > opts_act['success_thr']

            # Bbox regression
            if self.success:
                bbreg_samples = samples[top_idx]
                bbreg_feats = self.forward_samples(self.model_act_mdnet, image_pil, bbreg_samples)
                bbreg_samples = self.bbreg_act.predict(bbreg_feats, bbreg_samples)
                self.bbreg_bbox_act = bbreg_samples.mean(axis=0)

                self.img_learn.append(image_pil)
                self.pos_learn.append(target_bbox)
                # self.score_pos.append(target_score)
                self.frame_learn.append(self.frame_num)
                while len(self.img_learn) > 2*self.update_lenth:
                    del self.img_learn[0]
                    del self.pos_learn[0]
                    # del self.score_pos[0]
                    del self.frame_learn[0]
            else:
                self.bbreg_bbox_act = target_bbox

            # Save result
            self.result_act[self.frame_num] = target_bbox
            self.result_act_bb[self.frame_num] = self.bbreg_bbox_act

        translation_vec_2 = np.zeros(2)
        off_y = self.bbreg_bbox_act[1] + self.bbreg_bbox_act[3] / 2 - (self.target_bbox_act[1] + self.target_bbox_act[3] / 2)
        off_x = self.bbreg_bbox_act[0] + self.bbreg_bbox_act[2] / 2 - (self.target_bbox_act[0] + self.target_bbox_act[2] / 2)
        translation_vec_2[0] = off_y
        translation_vec_2[1] = off_x
        translation_vec_2 = torch.as_tensor(translation_vec_2, dtype=torch.float32, device=torch.device('cpu'))

        # # ↓↓↓ Modified by Y.Xiao
        # new_state = self.bbreg_bbox_act
        # self.target_bbox_act = new_state
        # self.target_bbox_history.append(self.target_bbox_act)
        # # ↑↑↑ Modified by Y.Xiao
        #
        # self.frame_num = self.frame_num + 1
        #
        # out = {'target_bbox': new_state.tolist()}
        # return out
        # ↑↑↑ Add ACT part - by Y.Xiao

        self.debug_info = {}

        self.frame_num += 1
        self.debug_info['frame_num'] = self.frame_num

        # Convert image
        im = numpy_to_torch(image)
        self.im = im    # For debugging only

        # ------- LOCALIZATION ------- #

        # Get sample
        sample_pos = self.pos.round()
        sample_scales = self.target_scale * self.params.scale_factors
        test_x = self.extract_processed_sample(im, self.pos, sample_scales, self.img_sample_sz)

        # Compute scores
        scores_raw = self.apply_filter(test_x)
        translation_vec, scale_ind, s, flag = self.localize_target(scores_raw)

        # Modified by Y.Xiao
        # delta_dis = translation_vec_2 - translation_vec
        # # translation_vec_final = translation_vec
        # if abs(delta_dis[0]+delta_dis[1]) > self.threshold_act_atom:
        #     translation_vec_final = translation_vec
        #     # print('vec overridden by ATOM:', translation_vec_2, '->', translation_vec)
        # else:
        #     translation_vec_final = translation_vec_2

        # pos_cand = [sample_pos + translation_vec, sample_pos + translation_vec_2]
        # out_of_bound = [(pos_cand[0][0] >= image.shape[0] or pos_cand[0][1] >= image.shape[1]),
        #                 (pos_cand[1][0] >= image.shape[0] or pos_cand[1][1] >= image.shape[1])]
        # if not out_of_bound[0] and not out_of_bound[1]:
        #     delta_score = s[0, 0, int(pos_cand[0][0] / image.shape[0] * s.shape[2]), int(
        #         pos_cand[0][1] / image.shape[1] * s.shape[3])] - \
        #                   s[0, 0, int(pos_cand[1][0] / image.shape[0] * s.shape[2]), int(
        #                       pos_cand[1][1] / image.shape[1] * s.shape[3])]
        #     if delta_score > 0.02:
        #         translation_vec_final = translation_vec
        #         # print('vec overridden by ATOM:', translation_vec_2, '->', translation_vec, delta_score, delta_dis)
        #     else:
        #         translation_vec_final = translation_vec_2
        # else:
        #     translation_vec_final = translation_vec_2

        target_disp_act = translation_vec_2 / self.target_scale / (self.img_support_sz / self.output_sz)
        disp_act = target_disp_act + self.output_sz // 2
        if int(disp_act[0]) >= s.shape[2] or int(disp_act[0]) < 0 or\
                int(disp_act[1]) >= s.shape[3] or int(disp_act[1]) < 0:
            score_act = -1
            print('out')
        else:
            score_act = s[0, 0, int(disp_act[0]), int(disp_act[1])]

        target_disp_atom = translation_vec / self.target_scale / (self.img_support_sz / self.output_sz)
        disp_atom = target_disp_atom + self.output_sz // 2
        score_atom = s[0, 0, int(disp_atom[0]), int(disp_atom[1])]

        delta_score = score_atom - score_act
        if delta_score > 0.1:
            # print(delta_score)
            translation_vec_final = translation_vec
        else:
            translation_vec_final = translation_vec_2

        # Update position and scale
        if flag != 'not_found':
            if self.use_iou_net:
                update_scale_flag = getattr(self.params, 'update_scale_when_uncertain', True) or flag != 'uncertain'
                if getattr(self.params, 'use_classifier', True):
                    self.update_state(sample_pos + translation_vec_final) # Modified by Y.Xiao
                self.refine_target_box(sample_pos, sample_scales[scale_ind], scale_ind, update_scale_flag)
            elif getattr(self.params, 'use_classifier', True):
                self.update_state(sample_pos + translation_vec_final, sample_scales[scale_ind]) # Modified by Y.Xiao

        score_map = s[scale_ind, ...]
        max_score = torch.max(score_map).item()
        self.debug_info['max_score'] = max_score
        self.debug_info['flag'] = flag

        if self.visdom is not None:
            self.visdom.register(score_map, 'heatmap', 2, 'Score Map')
            self.visdom.register(self.debug_info, 'info_dict', 1, 'Status')
        elif self.params.debug >= 2:
            show_tensor(score_map, 5, title='Max score = {:.2f}'.format(max_score))

        # ------- UPDATE ------- #

        # Check flags and set learning rate if hard negative
        update_flag = flag not in ['not_found', 'uncertain']
        hard_negative = (flag == 'hard_negative')
        learning_rate = self.params.hard_negative_learning_rate if hard_negative else None

        if update_flag:
            # Get train sample
            train_x = TensorList([x[scale_ind:scale_ind+1, ...] for x in test_x])

            # Create label for sample
            train_y = self.get_label_function(sample_pos, sample_scales[scale_ind])

            # Update memory
            self.update_memory(train_x, train_y, learning_rate)

        # Train filter
        if hard_negative:
            self.filter_optimizer.run(self.params.hard_negative_CG_iter)
        elif (self.frame_num-1) % self.params.train_skipping == 0:
            self.filter_optimizer.run(self.params.CG_iter)

        # Set the pos of the tracker to iounet pos
        if self.use_iou_net and flag != 'not_found':
            self.pos = self.pos_iounet.clone()

        # Return new state
        new_state = torch.cat((self.pos[[1,0]] - (self.target_sz[[1,0]]-1)/2, self.target_sz[[1,0]]))

        # ↓↓↓ Modified by Y.Xiao
        self.target_bbox_act = new_state.numpy()
        self.target_bbox_history.append(self.target_bbox_act)
        # print("Frame %d, bbox (%d,%d,%d,%d)" % \
        #     (self.frame_num, self.target_bbox_act[0], self.target_bbox_act[1], self.target_bbox_act[2], self.target_bbox_act[3]))
        # ↑↑↑ Modified by Y.Xiao

        out = {'target_bbox': new_state.tolist()}
        return out


    def apply_filter(self, sample_x: TensorList):
        return operation.conv2d(sample_x, self.filter, mode='same')

    def localize_target(self, scores_raw):
        # Weighted sum (if multiple features) with interpolation in fourier domain
        weight = self.fparams.attribute('translation_weight', 1.0)
        scores_raw = weight * scores_raw
        sf_weighted = fourier.cfft2(scores_raw) / (scores_raw.size(2) * scores_raw.size(3))
        for i, (sz, ksz) in enumerate(zip(self.feature_sz, self.kernel_size)):
            sf_weighted[i] = fourier.shift_fs(sf_weighted[i], math.pi * (1 - torch.Tensor([ksz[0]%2, ksz[1]%2]).cpu() / sz))  # modified by Y.Xiao

        torch.set_default_tensor_type('torch.FloatTensor')
        scores_fs = fourier.sum_fs(sf_weighted)
        scores = fourier.sample_fs(scores_fs.to('cpu'), self.output_sz.to('cpu')) # modified by Y.Xiao

        if self.output_window is not None and not getattr(self.params, 'perform_hn_without_windowing', False):
            scores *= self.output_window

        if getattr(self.params, 'advanced_localization', False):
            return self.localize_advanced(scores)

        # Get maximum
        max_score, max_disp = dcf.max2d(scores)
        _, scale_ind = torch.max(max_score, dim=0)
        max_disp = max_disp.float().cpu()

        # Convert to displacements in the base scale
        disp = (max_disp + self.output_sz / 2) % self.output_sz - self.output_sz / 2

        # Compute translation vector and scale change factor
        translation_vec = disp[scale_ind, ...].view(-1) * (self.img_support_sz / self.output_sz) * self.target_scale
        translation_vec *= self.params.scale_factors[scale_ind]

        # Shift the score output for visualization purposes
        if self.params.debug >= 2:
            sz = scores.shape[-2:]
            scores = torch.cat([scores[...,sz[0]//2:,:], scores[...,:sz[0]//2,:]], -2)
            scores = torch.cat([scores[...,:,sz[1]//2:], scores[...,:,:sz[1]//2]], -1)

        return translation_vec, scale_ind, scores, None

    def localize_advanced(self, scores):
        """Dows the advanced localization with hard negative detection and target not found."""

        sz = scores.shape[-2:]

        if self.output_window is not None and getattr(self.params, 'perform_hn_without_windowing', False):
            scores_orig = scores.clone()

            scores_orig = torch.cat([scores_orig[..., (sz[0] + 1) // 2:, :], scores_orig[..., :(sz[0] + 1) // 2, :]], -2)
            scores_orig = torch.cat([scores_orig[..., :, (sz[1] + 1) // 2:], scores_orig[..., :, :(sz[1] + 1) // 2]], -1)

            scores *= self.output_window

        # Shift scores back
        scores = torch.cat([scores[...,(sz[0]+1)//2:,:], scores[...,:(sz[0]+1)//2,:]], -2)
        scores = torch.cat([scores[...,:,(sz[1]+1)//2:], scores[...,:,:(sz[1]+1)//2]], -1)

        # Find maximum
        max_score1, max_disp1 = dcf.max2d(scores)
        _, scale_ind = torch.max(max_score1, dim=0)
        max_score1 = max_score1[scale_ind]
        max_disp1 = max_disp1[scale_ind,...].float().cpu().view(-1)
        target_disp1 = max_disp1 - self.output_sz // 2
        translation_vec1 = target_disp1 * (self.img_support_sz / self.output_sz) * self.target_scale

        if max_score1.item() < self.params.target_not_found_threshold:
            return translation_vec1, scale_ind, scores, 'not_found'

        if self.output_window is not None and getattr(self.params, 'perform_hn_without_windowing', False):
            scores = scores_orig

        # Mask out target neighborhood
        target_neigh_sz = self.params.target_neighborhood_scale * self.target_sz / self.target_scale
        tneigh_top = max(round(max_disp1[0].item() - target_neigh_sz[0].item() / 2), 0)
        tneigh_bottom = min(round(max_disp1[0].item() + target_neigh_sz[0].item() / 2 + 1), sz[0])
        tneigh_left = max(round(max_disp1[1].item() - target_neigh_sz[1].item() / 2), 0)
        tneigh_right = min(round(max_disp1[1].item() + target_neigh_sz[1].item() / 2 + 1), sz[1])
        scores_masked = scores[scale_ind:scale_ind+1,...].clone()
        scores_masked[...,tneigh_top:tneigh_bottom,tneigh_left:tneigh_right] = 0

        # Find new maximum
        max_score2, max_disp2 = dcf.max2d(scores_masked)
        max_disp2 = max_disp2.float().cpu().view(-1)
        target_disp2 = max_disp2 - self.output_sz // 2
        translation_vec2 = target_disp2 * (self.img_support_sz / self.output_sz) * self.target_scale

        # Handle the different cases
        if max_score2 > self.params.distractor_threshold * max_score1:
            disp_norm1 = torch.sqrt(torch.sum(target_disp1**2))
            disp_norm2 = torch.sqrt(torch.sum(target_disp2**2))
            disp_threshold = self.params.dispalcement_scale * math.sqrt(sz[0] * sz[1]) / 2

            if disp_norm2 > disp_threshold and disp_norm1 < disp_threshold:
                return translation_vec1, scale_ind, scores, 'hard_negative'
            if disp_norm2 < disp_threshold and disp_norm1 > disp_threshold:
                return translation_vec2, scale_ind, scores, 'hard_negative'
            if disp_norm2 > disp_threshold and disp_norm1 > disp_threshold:
                return translation_vec1, scale_ind, scores, 'uncertain'

            # If also the distractor is close, return with highest score
            return translation_vec1, scale_ind, scores, 'uncertain'

        if max_score2 > self.params.hard_negative_threshold * max_score1 and max_score2 > self.params.target_not_found_threshold:
            return translation_vec1, scale_ind, scores, 'hard_negative'

        return translation_vec1, scale_ind, scores, None


    def extract_sample(self, im: torch.Tensor, pos: torch.Tensor, scales, sz: torch.Tensor):
        return self.params.features.extract(im, pos, scales, sz)[0]

    def get_iou_features(self):
        return self.params.features.get_unique_attribute('iounet_features')

    def get_iou_backbone_features(self):
        return self.params.features.get_unique_attribute('iounet_backbone_features')

    def extract_processed_sample(self, im: torch.Tensor, pos: torch.Tensor, scales, sz: torch.Tensor) -> (TensorList, TensorList):
        x = self.extract_sample(im, pos, scales, sz)
        return self.preprocess_sample(self.project_sample(x))

    def preprocess_sample(self, x: TensorList) -> (TensorList, TensorList):
        if getattr(self.params, '_feature_window', False):
            x = x * self.feature_window
        return x

    def project_sample(self, x: TensorList, proj_matrix = None):
        # Apply projection matrix
        if proj_matrix is None:
            proj_matrix = self.projection_matrix
        return operation.conv2d(x, proj_matrix).apply(self.projection_activation)

    def init_learning(self):
        # Get window function
        self.feature_window = TensorList([dcf.hann2d(sz).to(self.params.device) for sz in self.feature_sz])

        # Filter regularization
        self.filter_reg = self.fparams.attribute('filter_reg')

        # Activation function after the projection matrix (phi_1 in the paper)
        projection_activation = getattr(self.params, 'projection_activation', 'none')
        if isinstance(projection_activation, tuple):
            projection_activation, act_param = projection_activation

        if projection_activation == 'none':
            self.projection_activation = lambda x: x
        elif projection_activation == 'relu':
            self.projection_activation = torch.nn.ReLU(inplace=True)
        elif projection_activation == 'elu':
            self.projection_activation = torch.nn.ELU(inplace=True)
        elif projection_activation == 'mlu':
            self.projection_activation = lambda x: F.elu(F.leaky_relu(x, 1 / act_param), act_param)
        else:
            raise ValueError('Unknown activation')

        # Activation function after the output scores (phi_2 in the paper)
        response_activation = getattr(self.params, 'response_activation', 'none')
        if isinstance(response_activation, tuple):
            response_activation, act_param = response_activation

        if response_activation == 'none':
            self.response_activation = lambda x: x
        elif response_activation == 'relu':
            self.response_activation = torch.nn.ReLU(inplace=True)
        elif response_activation == 'elu':
            self.response_activation = torch.nn.ELU(inplace=True)
        elif response_activation == 'mlu':
            self.response_activation = lambda x: F.elu(F.leaky_relu(x, 1 / act_param), act_param)
        else:
            raise ValueError('Unknown activation')


    def generate_init_samples(self, im: torch.Tensor) -> TensorList:
        """Generate augmented initial samples."""

        # Compute augmentation size
        aug_expansion_factor = getattr(self.params, 'augmentation_expansion_factor', None)
        aug_expansion_sz = self.img_sample_sz.clone()
        aug_output_sz = None
        if aug_expansion_factor is not None and aug_expansion_factor != 1:
            aug_expansion_sz = (self.img_sample_sz * aug_expansion_factor).long()
            aug_expansion_sz += (aug_expansion_sz - self.img_sample_sz.long()) % 2
            aug_expansion_sz = aug_expansion_sz.float()
            aug_output_sz = self.img_sample_sz.long().tolist()

        # Random shift operator
        get_rand_shift = lambda: None
        random_shift_factor = getattr(self.params, 'random_shift_factor', 0)
        if random_shift_factor > 0:
            get_rand_shift = lambda: ((torch.rand(2) - 0.5) * self.img_sample_sz * random_shift_factor).long().tolist()

        # Create transofmations
        self.transforms = [augmentation.Identity(aug_output_sz)]
        if 'shift' in self.params.augmentation:
            self.transforms.extend([augmentation.Translation(shift, aug_output_sz) for shift in self.params.augmentation['shift']])
        if 'relativeshift' in self.params.augmentation:
            get_absolute = lambda shift: (torch.Tensor(shift) * self.img_sample_sz/2).long().tolist()
            self.transforms.extend([augmentation.Translation(get_absolute(shift), aug_output_sz) for shift in self.params.augmentation['relativeshift']])
        if 'fliplr' in self.params.augmentation and self.params.augmentation['fliplr']:
            self.transforms.append(augmentation.FlipHorizontal(aug_output_sz, get_rand_shift()))
        if 'blur' in self.params.augmentation:
            self.transforms.extend([augmentation.Blur(sigma, aug_output_sz, get_rand_shift()) for sigma in self.params.augmentation['blur']])
        if 'scale' in self.params.augmentation:
            self.transforms.extend([augmentation.Scale(scale_factor, aug_output_sz, get_rand_shift()) for scale_factor in self.params.augmentation['scale']])
        if 'rotate' in self.params.augmentation:
            self.transforms.extend([augmentation.Rotate(angle, aug_output_sz, get_rand_shift()) for angle in self.params.augmentation['rotate']])

        # Generate initial samples
        init_samples = self.params.features.extract_transformed(im, self.pos, self.target_scale, aug_expansion_sz, self.transforms)

        # Remove augmented samples for those that shall not have
        for i, use_aug in enumerate(self.fparams.attribute('use_augmentation')):
            if not use_aug:
                init_samples[i] = init_samples[i][0:1, ...]

        # Add dropout samples
        if 'dropout' in self.params.augmentation:
            num, prob = self.params.augmentation['dropout']
            self.transforms.extend(self.transforms[:1]*num)
            for i, use_aug in enumerate(self.fparams.attribute('use_augmentation')):
                if use_aug:
                    init_samples[i] = torch.cat([init_samples[i], F.dropout2d(init_samples[i][0:1,...].expand(num,-1,-1,-1), p=prob, training=True)])

        return init_samples


    def init_projection_matrix(self, x):
        # Set if using projection matrix
        self.params.use_projection_matrix = getattr(self.params, 'use_projection_matrix', True)

        if self.params.use_projection_matrix:
            self.compressed_dim = self.fparams.attribute('compressed_dim', None)

            proj_init_method = getattr(self.params, 'proj_init_method', 'pca')
            if proj_init_method == 'pca':
                x_mat = TensorList([e.permute(1, 0, 2, 3).reshape(e.shape[1], -1).clone() for e in x])
                x_mat -= x_mat.mean(dim=1, keepdim=True)
                cov_x = x_mat @ x_mat.t()
                self.projection_matrix = TensorList(
                    [None if cdim is None else torch.svd(C)[0][:, :cdim].t().unsqueeze(-1).unsqueeze(-1).clone() for C, cdim in
                     zip(cov_x, self.compressed_dim)])
            elif proj_init_method == 'randn':
                self.projection_matrix = TensorList(
                    [None if cdim is None else ex.new_zeros(cdim,ex.shape[1],1,1).normal_(0,1/math.sqrt(ex.shape[1])) for ex, cdim in
                     zip(x, self.compressed_dim)])
        else:
            self.compressed_dim = x.size(1)
            self.projection_matrix = TensorList([None]*len(x))

    def init_label_function(self, train_x):
        # Allocate label function
        self.y = TensorList([x.new_zeros(self.params.sample_memory_size, 1, x.shape[2], x.shape[3]) for x in train_x])

        # Output sigma factor
        output_sigma_factor = self.fparams.attribute('output_sigma_factor')
        self.sigma = (self.feature_sz / self.img_support_sz * self.base_target_sz).prod().sqrt() * output_sigma_factor * torch.ones(2)

        # Center pos in normalized coords
        target_center_norm = (self.pos - self.pos.round()) / (self.target_scale * self.img_support_sz)

        # Generate label functions
        for y, sig, sz, ksz, x in zip(self.y, self.sigma, self.feature_sz, self.kernel_size, train_x):
            center_pos = sz * target_center_norm + 0.5 * torch.Tensor([(ksz[0] + 1) % 2, (ksz[1] + 1) % 2])
            for i, T in enumerate(self.transforms[:x.shape[0]]):
                sample_center = center_pos + torch.Tensor(T.shift) / self.img_support_sz * sz
                y[i, 0, ...] = dcf.label_function_spatial(sz, sig, sample_center)

        # Return only the ones to use for initial training
        return TensorList([y[:x.shape[0], ...] for y, x in zip(self.y, train_x)])


    def init_memory(self, train_x):
        # Initialize first-frame training samples
        self.num_init_samples = train_x.size(0)
        self.init_sample_weights = TensorList([x.new_ones(1) / x.shape[0] for x in train_x])
        self.init_training_samples = train_x

        # Sample counters and weights
        self.num_stored_samples = self.num_init_samples.copy()
        self.previous_replace_ind = [None] * len(self.num_stored_samples)
        self.sample_weights = TensorList([x.new_zeros(self.params.sample_memory_size) for x in train_x])
        for sw, init_sw, num in zip(self.sample_weights, self.init_sample_weights, self.num_init_samples):
            sw[:num] = init_sw

        # Initialize memory
        self.training_samples = TensorList(
            [x.new_zeros(self.params.sample_memory_size, cdim, x.shape[2], x.shape[3]) for x, cdim in
             zip(train_x, self.compressed_dim)])

    def update_memory(self, sample_x: TensorList, sample_y: TensorList, learning_rate = None):
        replace_ind = self.update_sample_weights(self.sample_weights, self.previous_replace_ind, self.num_stored_samples, self.num_init_samples, self.fparams, learning_rate)
        self.previous_replace_ind = replace_ind
        for train_samp, x, ind in zip(self.training_samples, sample_x, replace_ind):
            train_samp[ind:ind+1,...] = x
        for y_memory, y, ind in zip(self.y, sample_y, replace_ind):
            y_memory[ind:ind+1,...] = y
        if self.hinge_mask is not None:
            for m, y, ind in zip(self.hinge_mask, sample_y, replace_ind):
                m[ind:ind+1,...] = (y >= self.params.hinge_threshold).float()
        self.num_stored_samples += 1


    def update_sample_weights(self, sample_weights, previous_replace_ind, num_stored_samples, num_init_samples, fparams, learning_rate = None):
        # Update weights and get index to replace in memory
        replace_ind = []
        for sw, prev_ind, num_samp, num_init, fpar in zip(sample_weights, previous_replace_ind, num_stored_samples, num_init_samples, fparams):
            lr = learning_rate
            if lr is None:
                lr = fpar.learning_rate

            init_samp_weight = getattr(fpar, 'init_samples_minimum_weight', None)
            if init_samp_weight == 0:
                init_samp_weight = None
            s_ind = 0 if init_samp_weight is None else num_init

            if num_samp == 0 or lr == 1:
                sw[:] = 0
                sw[0] = 1
                r_ind = 0
            else:
                # Get index to replace
                _, r_ind = torch.min(sw[s_ind:], 0)
                r_ind = r_ind.item() + s_ind

                # Update weights
                if prev_ind is None:
                    sw /= 1 - lr
                    sw[r_ind] = lr
                else:
                    sw[r_ind] = sw[prev_ind] / (1 - lr)

            sw /= sw.sum()
            if init_samp_weight is not None and sw[:num_init].sum() < init_samp_weight:
                sw /= init_samp_weight + sw[num_init:].sum()
                sw[:num_init] = init_samp_weight / num_init

            replace_ind.append(r_ind)

        return replace_ind

    def get_label_function(self, sample_pos, sample_scale):
        # Generate label function
        train_y = TensorList()
        target_center_norm = (self.pos - sample_pos) / (sample_scale * self.img_support_sz)
        for sig, sz, ksz in zip(self.sigma, self.feature_sz, self.kernel_size):
            center = sz * target_center_norm + 0.5 * torch.Tensor([(ksz[0] + 1) % 2, (ksz[1] + 1) % 2]).cpu()  # modified by Y.Xiao
            train_y.append(dcf.label_function_spatial(sz, sig, center))
        return train_y

    def update_state(self, new_pos, new_scale = None):
        # Update scale
        if new_scale is not None:
            self.target_scale = new_scale.clamp(self.min_scale_factor, self.max_scale_factor)
            self.target_sz = self.base_target_sz * self.target_scale

        # Update pos
        inside_ratio = 0.2
        inside_offset = (inside_ratio - 0.5) * self.target_sz
        self.pos = torch.max(torch.min(new_pos, self.image_sz - inside_offset), inside_offset)

    def get_iounet_box(self, pos, sz, sample_pos, sample_scale):
        """All inputs in original image coordinates"""
        box_center = (pos - sample_pos) / sample_scale + (self.iou_img_sample_sz - 1) / 2
        box_sz = sz / sample_scale
        target_ul = box_center - (box_sz - 1) / 2
        return torch.cat([target_ul.flip((0,)), box_sz.flip((0,))])

    def init_iou_net(self):
        # Setup IoU net
        self.iou_predictor = self.params.features.get_unique_attribute('iou_predictor')
        for p in self.iou_predictor.parameters():
            p.requires_grad = False

        # Get target boxes for the different augmentations
        self.iou_target_box = self.get_iounet_box(self.pos, self.target_sz, self.pos.round(), self.target_scale)
        target_boxes = TensorList()
        if self.params.iounet_augmentation:
            for T in self.transforms:
                if not isinstance(T, (augmentation.Identity, augmentation.Translation, augmentation.FlipHorizontal, augmentation.FlipVertical, augmentation.Blur)):
                    break
                target_boxes.append(self.iou_target_box + torch.Tensor([T.shift[1], T.shift[0], 0, 0]))
        else:
            target_boxes.append(self.iou_target_box.clone())
        target_boxes = torch.cat(target_boxes.view(1,4), 0).to(self.params.device)

        # Get iou features
        iou_backbone_features = self.get_iou_backbone_features()

        # Remove other augmentations such as rotation
        iou_backbone_features = TensorList([x[:target_boxes.shape[0],...] for x in iou_backbone_features])

        # Extract target feat
        with torch.no_grad():
            target_feat = self.iou_predictor.get_modulation(iou_backbone_features, target_boxes)
        self.target_feat = TensorList([x.detach().mean(0) for x in target_feat])

        if getattr(self.params, 'iounet_not_use_reference', False):
            self.target_feat = TensorList([torch.full_like(tf, tf.norm() / tf.numel()) for tf in self.target_feat])


    def refine_target_box(self, sample_pos, sample_scale, scale_ind, update_scale = True):
        # Initial box for refinement
        init_box = self.get_iounet_box(self.pos, self.target_sz, sample_pos, sample_scale)

        # Extract features from the relevant scale
        iou_features = self.get_iou_features()
        iou_features = TensorList([x[scale_ind:scale_ind+1,...] for x in iou_features])

        init_boxes = init_box.view(1,4).clone()
        if self.params.num_init_random_boxes > 0:
            # Get random initial boxes
            square_box_sz = init_box[2:].prod().sqrt()
            rand_factor = square_box_sz * torch.cat([self.params.box_jitter_pos * torch.ones(2), self.params.box_jitter_sz * torch.ones(2)])
            minimal_edge_size = init_box[2:].min()/3
            rand_bb = (torch.rand(self.params.num_init_random_boxes, 4) - 0.5) * rand_factor
            new_sz = (init_box[2:].cpu() + rand_bb[:,2:].cpu()).clamp(minimal_edge_size)   # modified by Y.Xiao
            new_center = (init_box[:2] + init_box[2:]/2).cpu() + rand_bb[:,:2].cpu() # modified by Y.Xiao
            init_boxes = torch.cat([new_center - new_sz/2, new_sz], 1)
            init_boxes = torch.cat([init_box.view(1,4), init_boxes])

        # Refine boxes by maximizing iou
        output_boxes, output_iou = self.optimize_boxes(iou_features, init_boxes)

        # Remove weird boxes with extreme aspect ratios
        output_boxes[:, 2:].clamp_(1)
        aspect_ratio = output_boxes[:,2] / output_boxes[:,3]
        keep_ind = (aspect_ratio < self.params.maximal_aspect_ratio) * (aspect_ratio > 1/self.params.maximal_aspect_ratio)
        output_boxes = output_boxes[keep_ind,:]
        output_iou = output_iou[keep_ind]

        # If no box found
        if output_boxes.shape[0] == 0:
            return

        # Take average of top k boxes
        k = getattr(self.params, 'iounet_k', 5)
        topk = min(k, output_boxes.shape[0])
        _, inds = torch.topk(output_iou, topk)
        predicted_box = output_boxes[inds, :].mean(0)
        predicted_iou = output_iou.view(-1, 1)[inds, :].mean(0)

        # Update position
        new_pos = predicted_box[:2] + predicted_box[2:]/2 - (self.iou_img_sample_sz - 1) / 2
        new_pos = new_pos.flip((0,)) * sample_scale + sample_pos
        new_target_sz = predicted_box[2:].flip((0,)) * sample_scale
        new_scale = torch.sqrt(new_target_sz.prod() / self.base_target_sz.prod())

        self.pos_iounet = new_pos.clone()

        if getattr(self.params, 'use_iounet_pos_for_learning', True):
            self.pos = new_pos.clone()

        self.target_sz = new_target_sz

        if update_scale:
            self.target_scale = new_scale

    def optimize_boxes(self, iou_features, init_boxes):
        # Optimize iounet boxes
        output_boxes = init_boxes.view(1, -1, 4).to(self.params.device)
        step_length = self.params.box_refinement_step_length

        for i_ in range(self.params.box_refinement_iter):
            # forward pass
            bb_init = output_boxes.clone().detach()
            bb_init.requires_grad = True

            outputs = self.iou_predictor.predict_iou(self.target_feat, iou_features, bb_init)

            if isinstance(outputs, (list, tuple)):
                outputs = outputs[0]

            outputs.backward(gradient = torch.ones_like(outputs))

            # Update proposal
            output_boxes = bb_init + step_length * bb_init.grad * bb_init[:, :, 2:].repeat(1, 1, 2)
            output_boxes.detach_()

            step_length *= self.params.box_refinement_step_decay

        return output_boxes.view(-1,4).cpu(), outputs.detach().view(-1).cpu()

    # ↓↓↓ Add ACT init - by Y.Xiao
    def getbatch_actor(self, img, boxes):
        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)
        crop_size = 107

        num_boxes = boxes.shape[0]
        imo_g = np.zeros([num_boxes, crop_size, crop_size, 3])
        imo_l = np.zeros([num_boxes, crop_size, crop_size, 3])

        for i in range(num_boxes):
            bbox = boxes[i]
            img_crop_l, img_crop_g, out_flag = self.crop_image_actor(img, bbox)

            imo_g[i] = img_crop_g
            imo_l[i] = img_crop_l

        imo_g = imo_g.transpose(0, 3, 1, 2).astype('float32')
        imo_g = imo_g - 128.
        imo_g = torch.from_numpy(imo_g)
        imo_g = Variable(imo_g)
        imo_g = imo_g.cuda()
        imo_l = imo_l.transpose(0, 3, 1, 2).astype('float32')
        imo_l = imo_l - 128.
        imo_l = torch.from_numpy(imo_l)
        imo_l = Variable(imo_l)
        imo_l = imo_l.cuda()

        return imo_g, imo_l, out_flag

    def init_actor(self, actor, image, gt):
        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)

        batch_num = 64
        maxiter = 80
        actor = actor.cuda()
        actor.train()
        init_optimizer = torch.optim.Adam(actor.parameters(), lr=0.0001)
        loss_func = torch.nn.MSELoss()
        _, _, out_flag_first = self.getbatch_actor(np.array(image), np.array(gt).reshape([1, 4]))
        actor_samples = np.round(gen_samples(SampleGenerator('uniform', image.size, 0.3, 1.5, None),
                                             gt, 1500, [0.6, 1], [0.9, 1.1]))
        idx = np.random.permutation(actor_samples.shape[0])
        batch_img_g, batch_img_l, _ = self.getbatch_actor(np.array(image), actor_samples)
        batch_distance = self.cal_distance(actor_samples, np.tile(gt, [actor_samples.shape[0], 1]))
        batch_distance = np.array(batch_distance).astype(np.float32)

        while (len(idx) < batch_num * maxiter):
            idx = np.concatenate([idx, np.random.permutation(actor_samples.shape[0])])

        pointer = 0

        for iter in range(maxiter):

            next = pointer + batch_num
            cur_idx = idx[pointer: next]
            pointer = next
            feat = actor(batch_img_l[cur_idx], batch_img_g[cur_idx])

            loss = loss_func(feat, Variable(
                torch.FloatTensor(batch_distance[cur_idx]).cuda()))  # must be (1. nn output, 2. target)

            actor.zero_grad()  # clear gradients for next train
            loss.backward()  # backpropagation, compute gradients
            init_optimizer.step()  # apply gradients
            if opts_act['show_train']:
                print("Iter %d, Loss %.10f" % (iter, loss.data))
            if loss.data < 0.0001:
                deta_flag = 0
                # print iter
                return deta_flag, out_flag_first
        deta_flag = 1
        return deta_flag, out_flag_first

    def cal_distance(self, samples, ground_th):
        distance = samples[:, 0:2] + samples[:, 2:4] / 2.0 - ground_th[:, 0:2] - ground_th[:, 2:4] / 2.0
        distance = distance / samples[:, 2:4]
        rate = ground_th[:, 3] / samples[:, 3]
        rate = np.array(rate).reshape(rate.shape[0], 1)
        rate = rate - 1.0
        distance = np.hstack([distance, rate])
        return distance

    def forward_samples(self, model, image, samples, out_layer='conv3'):
        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)

        model.eval()
        extractor = RegionExtractor(image, samples, opts_act['img_size'], opts_act['padding'], opts_act['batch_test'])
        for i, regions in enumerate(extractor):
            regions = Variable(regions)
            if opts_act['use_gpu']:
                regions = regions.cuda()
            feat = model(regions, out_layer=out_layer)
            if i == 0:
                feats = feat.data.clone()
            else:
                feats = torch.cat((feats, feat.data.clone()), 0)
        return feats

    def set_optimizer(self, model, lr_base, lr_mult=opts_act['lr_mult'], momentum=opts_act['momentum'], w_decay=opts_act['w_decay']):
        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)
        params = model.get_learnable_params()
        param_list = []
        for k, p in params.items():
            lr = lr_base
            for l, m in lr_mult.items():
                if k.startswith(l):
                    lr = lr_base * m
            param_list.append({'params': [p], 'lr': lr})
        optimizer = optim.SGD(param_list, lr=lr, momentum=momentum, weight_decay=w_decay)
        return optimizer

    def train_act(self, model, criterion, optimizer, pos_feats, neg_feats, maxiter, in_layer='fc4'):
        np.random.seed(123)
        torch.manual_seed(456)
        torch.cuda.manual_seed(789)

        model.train()

        batch_pos = opts_act['batch_pos']
        batch_neg = opts_act['batch_neg']
        batch_test = opts_act['batch_test']
        batch_neg_cand = max(opts_act['batch_neg_cand'], batch_neg)

        pos_idx = np.random.permutation(pos_feats.size(0))
        neg_idx = np.random.permutation(neg_feats.size(0))
        while (len(pos_idx) < batch_pos * maxiter):
            pos_idx = np.concatenate([pos_idx, np.random.permutation(pos_feats.size(0))])
        while (len(neg_idx) < batch_neg_cand * maxiter):
            neg_idx = np.concatenate([neg_idx, np.random.permutation(neg_feats.size(0))])
        pos_pointer = 0
        neg_pointer = 0

        for iter in range(maxiter):

            # select pos idx
            pos_next = pos_pointer + batch_pos
            pos_cur_idx = pos_idx[pos_pointer:pos_next]
            pos_cur_idx = pos_feats.new(pos_cur_idx).long()
            pos_pointer = pos_next

            # select neg idx
            neg_next = neg_pointer + batch_neg_cand
            neg_cur_idx = neg_idx[neg_pointer:neg_next]
            neg_cur_idx = neg_feats.new(neg_cur_idx).long()
            neg_pointer = neg_next

            # create batch
            batch_pos_feats = Variable(pos_feats.index_select(0, pos_cur_idx))
            batch_neg_feats = Variable(neg_feats.index_select(0, neg_cur_idx))

            # hard negative mining
            if batch_neg_cand > batch_neg:
                model.eval()
                for start in range(0, batch_neg_cand, batch_test):
                    end = min(start + batch_test, batch_neg_cand)
                    score = model(batch_neg_feats[start:end], in_layer=in_layer)
                    if start == 0:
                        neg_cand_score = score.data[:, 1].clone()
                    else:
                        neg_cand_score = torch.cat((neg_cand_score, score.data[:, 1].clone()), 0)

                _, top_idx = neg_cand_score.topk(batch_neg)
                batch_neg_feats = batch_neg_feats.index_select(0, Variable(top_idx))
                model.train()

            # forward
            pos_score = model(batch_pos_feats, in_layer=in_layer)
            neg_score = model(batch_neg_feats, in_layer=in_layer)

            # optimize
            loss = criterion(pos_score, neg_score)
            model.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm(model.parameters(), opts_act['grad_clip'])
            optimizer.step()
            if opts_act['show_train']:
                print("Iter %d, Loss %.10f" % (iter, loss.data))

    def _init_video(self, img_path, video):
        if 'vot' in img_path:
            video_folder = os.path.join(img_path, video)
        else:
            video_folder = os.path.join(img_path, video, 'img')
        frame_name_list = [f for f in os.listdir(video_folder) if f.endswith(".jpg")]
        frame_name_list = [os.path.join(video_folder, '') + s for s in frame_name_list]
        frame_name_list.sort()

        img = Image.open(frame_name_list[0])
        frame_sz = np.asarray(img.size)
        frame_sz[1], frame_sz[0] = frame_sz[0], frame_sz[1]

        if 'vot' in img_path:
            gt_file = os.path.join(video_folder, 'groundtruth.txt')
        else:
            gt_file = os.path.join(os.path.join(img_path, video), 'groundtruth_rect.txt')
        gt = np.genfromtxt(gt_file, delimiter=',')
        if gt.shape.__len__() == 1:  # isnan(gt[0])
            gt = np.loadtxt(gt_file)
        n_frames = len(frame_name_list)
        assert n_frames == len(gt), 'Number of frames and number of GT lines should be equal.'

        return gt, frame_name_list, frame_sz, n_frames

    def crop_image_actor(self, img, bbox, img_size=107, padding=0, valid=False):
        x, y, w, h = np.array(bbox, dtype='float32')

        half_w, half_h = w / 2, h / 2
        center_x, center_y = x + half_w, y + half_h
        out_flag = 0
        if padding > 0:
            pad_w = padding * w / img_size
            pad_h = padding * h / img_size
            half_w += pad_w
            half_h += pad_h

        img_h, img_w, _ = img.shape
        min_x = int(center_x - half_w + 0.5)
        min_y = int(center_y - half_h + 0.5)
        max_x = int(center_x + half_w + 0.5)
        max_y = int(center_y + half_h + 0.5)

        if min_x >= 0 and min_y >= 0 and max_x <= img_w and max_y <= img_h:
            cropped = img[min_y:max_y, min_x:max_x, :]

        else:
            min_x_val = max(0, min_x)
            min_y_val = max(0, min_y)
            max_x_val = min(img_w, max_x)
            max_y_val = min(img_h, max_y)

            cropped = 128 * np.ones((max_y - min_y, max_x - min_x, 3), dtype='uint8')
            cropped[min_y_val - min_y:max_y_val - min_y, min_x_val - min_x:max_x_val - min_x, :] \
                = img[min_y_val:max_y_val, min_x_val:max_x_val, :]

        # scaled_l = imresize(cropped, (img_size, img_size))
        scaled_l = np.array(Image.fromarray(cropped).resize((img_size, img_size)))

        min_x = int(center_x - w + 0.5)
        min_y = int(center_y - h + 0.5)
        max_x = int(center_x + w + 0.5)
        max_y = int(center_y + h + 0.5)

        if min_x >= 0 and min_y >= 0 and max_x <= img_w and max_y <= img_h:
            cropped = img[min_y:max_y, min_x:max_x, :]

        else:
            min_x_val = max(0, min_x)
            min_y_val = max(0, min_y)
            max_x_val = min(img_w, max_x)
            max_y_val = min(img_h, max_y)
            if max(abs(min_y - min_y_val) / half_h, abs(max_y - max_y_val) / half_h, abs(min_x - min_x_val) / half_w,
                   abs(max_x - max_x_val) / half_w) > 0.3:
                out_flag = 1
            cropped = 128 * np.ones((max_y - min_y, max_x - min_x, 3), dtype='uint8')
            cropped[min_y_val - min_y:max_y_val - min_y, min_x_val - min_x:max_x_val - min_x, :] \
                = img[min_y_val:max_y_val, min_x_val:max_x_val, :]

        # scaled_g = imresize(cropped, (img_size, img_size))
        scaled_g = np.array(Image.fromarray(cropped).resize((img_size, img_size)))

        return scaled_l, scaled_g, out_flag

    def crop_image_actor_2(self, img, bbox, img_size=107, padding=0, valid=False):
        x, y, w, h = np.array(bbox, dtype='float32')

        half_w, half_h = w / 2, h / 2
        center_x, center_y = x + half_w, y + half_h
        out_flag = 0
        if padding > 0:
            pad_w = padding * w / img_size
            pad_h = padding * h / img_size
            half_w += pad_w
            half_h += pad_h

        img_h, img_w, _ = img.shape

        min_x = int(center_x - 1.5 * w + 0.5)
        min_y = int(center_y - 1.5 * h + 0.5)
        max_x = int(center_x + 1.5 * w + 0.5)
        max_y = int(center_y + 1.5 * h + 0.5)

        if min_x >= 0 and min_y >= 0 and max_x <= img_w and max_y <= img_h:
            cropped = img[min_y:max_y, min_x:max_x, :]

        else:
            min_x_val = max(0, min_x)
            min_y_val = max(0, min_y)
            max_x_val = min(img_w, max_x)
            max_y_val = min(img_h, max_y)
            if max(abs(min_y - min_y_val) / half_h, abs(max_y - max_y_val) / half_h, abs(min_x - min_x_val) / half_w,
                   abs(max_x - max_x_val) / half_w) > 0.3:
                out_flag = 1
            cropped = 128 * np.ones((max_y - min_y, max_x - min_x, 3), dtype='uint8')
            cropped[min_y_val - min_y:max_y_val - min_y, min_x_val - min_x:max_x_val - min_x, :] \
                = img[min_y_val:max_y_val, min_x_val:max_x_val, :]

        # scaled_g = imresize(cropped, (img_size, img_size))
        # scaled_g = np.array(Image.fromarray(cropped).resize((img_size, img_size)))
        scaled_g = np.array(Image.fromarray(cropped))

        return scaled_g, out_flag

    def crop_image_actor_center(self, img, bbox, img_size=107, padding=0, valid=False):
        x, y, w, h = np.array(bbox, dtype='float32')

        img_h, img_w = img.shape

        half_w, half_h = img_w / 2, img_h / 2
        center_x, center_y = 0 + half_w, 0 + half_h
        out_flag = 0

        min_x = int(center_x - 0.5 * w + 0.5)
        min_y = int(center_y - 0.5 * h + 0.5)
        max_x = int(center_x + 0.5 * w + 0.5)
        max_y = int(center_y + 0.5 * h + 0.5)

        if min_x >= 0 and min_y >= 0 and max_x <= img_w and max_y <= img_h:
            cropped = img[min_y:max_y, min_x:max_x]

        else:
            min_x_val = max(0, min_x)
            min_y_val = max(0, min_y)
            max_x_val = min(img_w, max_x)
            max_y_val = min(img_h, max_y)
            if max(abs(min_y - min_y_val) / half_h, abs(max_y - max_y_val) / half_h, abs(min_x - min_x_val) / half_w,
                   abs(max_x - max_x_val) / half_w) > 0.3:
                out_flag = 1
            cropped = 128 * np.ones((max_y - min_y, max_x - min_x, 3), dtype='uint8')
            cropped[min_y_val - min_y:max_y_val - min_y, min_x_val - min_x:max_x_val - min_x, :] \
                = img[min_y_val:max_y_val, min_x_val:max_x_val, :]

        # scaled_g = imresize(cropped, (img_size, img_size))
        # scaled_g = np.array(Image.fromarray(cropped).resize((img_size, img_size)))
        # scaled_center = np.array(Image.fromarray(cropped))

        return cropped, out_flag

    def move_crop(self, pos_, deta_pos, img_size, rate):
        flag = 0
        if pos_.shape.__len__() == 1:
            pos_ = np.array(pos_).reshape([1, 4])
            deta_pos = np.array(deta_pos).reshape([1, 3])
            flag = 1
        pos_deta = deta_pos[:, 0:2] * pos_[:, 2:]
        pos = np.copy(pos_)
        center = pos[:, 0:2] + pos[:, 2:4] / 2
        center_ = center - pos_deta
        pos[:, 2] = pos[:, 2] * (1 + deta_pos[:, 2])
        pos[:, 3] = pos[:, 3] * (1 + deta_pos[:, 2])

        if np.max((pos[:, 3] > (pos[:, 2] / rate) * 1.2)) == 1.0:
            pos[:, 3] = pos[:, 2] / rate

        if np.max((pos[:, 3] < (pos[:, 2] / rate) / 1.2)) == 1.0:
            pos[:, 2] = pos[:, 3] * rate

        pos[pos[:, 2] < 10, 2] = 10
        pos[pos[:, 3] < 10, 3] = 10

        pos[:, 0:2] = center_ - pos[:, 2:4] / 2

        pos[pos[:, 0] > img_size[1], 0] = img_size[1]
        pos[pos[:, 1] > img_size[0], 1] = img_size[0]
        pos[pos[:, 0] < -pos[:, 2], 0] = -pos[:, 2]
        pos[pos[:, 1] < -pos[:, 3], 1] = -pos[:, 2]

        if flag == 1:
            pos = pos[0]

        return pos

    def move_crop_2(self, pos_, deta_pos, img_size, rate):
        pos___ = pos_
        translation_vec = np.zeros(2)
        flag = 0
        if pos_.shape.__len__() == 1:
            pos_ = np.array(pos_).reshape([1, 4])
            deta_pos = np.array(deta_pos).reshape([1, 3])
            flag = 1
        pos_deta = deta_pos[:, 0:2] * pos_[:, 2:]
        pos = np.copy(pos_)
        center = pos[:, 0:2] + pos[:, 2:4] / 2
        center_ = center - pos_deta
        pos[:, 2] = pos[:, 2] * (1 + deta_pos[:, 2])
        pos[:, 3] = pos[:, 3] * (1 + deta_pos[:, 2])

        if np.max((pos[:, 3] > (pos[:, 2] / rate) * 1.2)) == 1.0:
            pos[:, 3] = pos[:, 2] / rate

        if np.max((pos[:, 3] < (pos[:, 2] / rate) / 1.2)) == 1.0:
            pos[:, 2] = pos[:, 3] * rate

        pos[pos[:, 2] < 10, 2] = 10
        pos[pos[:, 3] < 10, 3] = 10

        pos[:, 0:2] = center_ - pos[:, 2:4] / 2

        pos[pos[:, 0] > img_size[1], 0] = img_size[1]
        pos[pos[:, 1] > img_size[0], 1] = img_size[0]
        pos[pos[:, 0] < -pos[:, 2], 0] = -pos[:, 2]
        pos[pos[:, 1] < -pos[:, 3], 1] = -pos[:, 2]

        if flag == 1:
            pos = pos[0]

        # calculate offset of y
        off_y = pos[1] + pos[3] / 2 - pos___[1] - pos___[3] / 2
        # calculate offset of x
        off_x = pos[0] + pos[2] / 2 - pos___[0] - pos___[2] / 2

        translation_vec[0] = off_y
        translation_vec[1] = off_x

        translation_vec = torch.as_tensor(translation_vec, dtype=torch.float32, device=torch.device('cpu'))
        # translation_vec = torch.FloatTensor(translation_vec)

        return translation_vec

    def crop_image_blur(self, img, bbox):
        x, y, w, h = np.array(bbox, dtype='float32')
        img_h, img_w, _ = img.shape
        half_w, half_h = w / 2, h / 2
        center_x, center_y = x + half_w, y + half_h

        min_x = int(center_x - w + 0.5)
        min_y = int(center_y - h + 0.5)
        max_x = int(center_x + w + 0.5)
        max_y = int(center_y + h + 0.5)

        if min_x >= 0 and min_y >= 0 and max_x <= img_w and max_y <= img_h:
            cropped = img[min_y:max_y, min_x:max_x, :]

        else:
            min_x_val = max(0, min_x)
            min_y_val = max(0, min_y)
            max_x_val = min(img_w, max_x)
            max_y_val = min(img_h, max_y)
            cropped = img[min_y_val:max_y_val, min_x_val:max_x_val, :]

        return cropped

    def load(self, url):
        """
        Given an url of an image, downloads the image and
        returns a PIL image
        """
        response = requests.get(url)
        pil_image = Image.open(BytesIO(response.content)).convert("RGB")
        # convert to BGR format
        image = np.array(pil_image)[:, :, [2, 1, 0]]
        return image

    def imshow(self, img):
        plt.figure()
        plt.imshow(img[:, :, [2, 1, 0]])
        plt.axis("off")

    def maskrcnn_demo(self):
        config_file = "/media/test/Data/Dev_linux/Python3/maskrcnn-benchmark/configs/caffe2/e2e_mask_rcnn_R_50_FPN_1x_caffe2.yaml"

        # update the config options with the config file
        cfg.merge_from_file(config_file)
        # manual override some options
        cfg.merge_from_list(["MODEL.DEVICE", "cuda"])

        coco_demo = COCODemo(
            cfg,
            min_image_size=800,
            confidence_threshold=0.7,
        )

        # from http://cocodataset.org/#explore?id=345434
        image = self.load("https://inews.gtimg.com/newsapp_ls/0/10947814918_580328/0")
        image2 = image[:, :, [2, 1, 0]]
        # plt.imshow(image2)
        # plt.show()

        # compute predictions
        top_predictions, predictions_img = coco_demo.run_on_opencv_image(image)
        self.imshow(predictions_img)
        # plt.show()

    def maskrcnn_call(self, img):
        config_file = "/media/test/Data/Dev_linux/Python3/maskrcnn-benchmark/configs/caffe2/e2e_mask_rcnn_R_50_FPN_1x_caffe2.yaml"
        cfg.merge_from_file(config_file)
        cfg.merge_from_list(["MODEL.DEVICE", "cuda"])

        coco_demo = COCODemo(
            cfg,
            min_image_size=800,
            confidence_threshold=0.7,
        )

        # compute predictions
        top_predictions, predictions_img = coco_demo.run_on_opencv_image(img)
        if self.need_debug_image:
            self.imshow(predictions_img)

        return top_predictions

    def yolactplus_call(self, img):
        result = 0
        eval2.test()
        return result

    def get_spatial_attention(self, mask_np, epane_padding, crop_padding = 1):
        # mask = top_predictions.extra_fields['mask'][0][0]
        # mask = mask.numpy()
        # mask = mask + 0
        if self.need_debug_image:
            Image.fromarray(np.uint8(mask_np * 255), 'L').show()

        ori_center_x = self.target_bbox_act[0] + round(self.target_bbox_act[2] / 2, 0)
        ori_center_y = self.target_bbox_act[1] + round(self.target_bbox_act[3] / 2, 0)
        new_bbox = [0, 0, 0, 0]
        new_bbox[2] = self.target_bbox_act[2] * crop_padding
        new_bbox[3] = self.target_bbox_act[3] * crop_padding
        new_bbox[0] = ori_center_x - round(new_bbox[2] / 2, 0)
        new_bbox[1] = ori_center_y - round(new_bbox[3] / 2, 0)
        cropped_center, out_flag = self.crop_image_actor_center(mask_np, new_bbox)

        #mask = mask.resize((img_size, img_size))
        mask_pil = Image.fromarray(np.uint8(cropped_center * 255), 'L')

        if self.need_debug_image:
            mask_pil.show()

        # Ready to get location prior
        img_sz = [0, 0]
        img_sz[0] = cropped_center.shape[1] * epane_padding
        img_sz[1] = cropped_center.shape[0] * epane_padding

        target_sz = [0, 0]
        target_sz[0] = cropped_center.shape[1]
        target_sz[1] = cropped_center.shape[0]

        # We should convert the image scale to 1:1
        roi = [0, 0, 0, 0]
        roi[0] = 0
        roi[1] = 0
        if (target_sz[0] >= target_sz[1]):
            roi[2] = epane_padding * target_sz[0]
            roi[3] = epane_padding * target_sz[0]
            target_sz[1] = target_sz[0]
            img_sz[1] = img_sz[0]
        else:
            roi[2] = epane_padding * target_sz[1]
            roi[3] = epane_padding * target_sz[1]
            target_sz[0] = target_sz[1]
            img_sz[0] = img_sz[1]

        # round_prior is an numpy array
        round_prior = self.get_location_prior(roi, target_sz, img_sz)
        if self.need_debug_image:
            Image.fromarray(round_prior * 255).show()

        # change the round shape to elliptical
        # round_prior.resize((round(cropped_center.shape[1] * 2.5), round(cropped_center.shape[0] * 2.5)), refcheck=False)
        # Image.fromarray(round_prior * 255).show()

        # Resize mask_pil to 1:1
        if (target_sz[0] >= target_sz[1]):
            mask_pil = mask_pil.resize((target_sz[0], target_sz[0]))
        else:
            mask_pil = mask_pil.resize((target_sz[1], target_sz[1]))

        mask_pil_with_padding = self.pad_image(mask_pil, (round_prior.shape[1], round_prior.shape[0]))
        if self.need_debug_image:
            mask_pil_with_padding.show()

        # Overlay Epanechnikov and mask
        mask_pil_with_padding_nd = np.array(mask_pil_with_padding)[:,:,0]
        spatial_attention_map = self.overlay_operation(mask_pil_with_padding_nd, round_prior)

        return spatial_attention_map

    def overlay_operation(self, mask_nd, prior_nd):
        mask_nd = mask_nd / 255
        # find pure black indexes
        index_t_1 = np.where(prior_nd >= 0.7)
        index_t_2 = np.where(mask_nd == 0)
        (result_0, result_1) = self.find_pure_black(index_t_1, mask_nd)

        result = mask_nd * prior_nd
        result[result_0, result_1] = prior_nd[result_0, result_1]
        result_pil = Image.fromarray(result * 255).convert('L').filter(ImageFilter.GaussianBlur(3))
        if self.need_debug_image:
            result_pil.show()
        result = np.array(result_pil)

        return result

    def find_pure_black(self, index_t_1, mask_nd):
        result_0 = []
        result_1 = []
        for i in range(len(index_t_1[0])):
            first = index_t_1[0][i]
            second = index_t_1[1][i]
            if mask_nd[first][second] == 0:
                result_0.append(index_t_1[0][i])
                result_1.append(index_t_1[1][i])

        return result_0, result_1

    def get_location_prior(self, roi, target_sz, img_sz):
        """
        :param roi: top_left and bottom_right point
        :param target_sz:
        :param img_sz:
        :return:
        """
        w, h = img_sz
        x1 = int(round(max(min(roi[0] - 1, w - 1), 0)))
        y1 = int(round(max(min(roi[1] - 1, h - 1), 0)))
        x2 = int(round(min(max(roi[2] - 1, 0), w - 1)))
        y2 = int(round(min(max(roi[3] - 1, 0), h - 1)))
        # make it rotationaly invariant
        target_size = min(target_sz[0], target_sz[1])
        target_sz = (target_size, target_size)

        kernel_size_width = 1 / (0.5 * target_sz[0] * 1.4142 + 1)
        kernel_size_height = 1 / (0.5 * target_sz[1] * 1.4142 + 1)
        cx = x1 + 0.5 * (x2 - x1)
        cy = y1 + 0.5 * (y2 - y1)

        kernel_weight = np.zeros((1 + int(np.floor(y2 - y1)), 1 + int(np.floor(-(x1 - cx) + x2 - cx))))
        ys = np.arange(y1, y2 + 1)
        xs = np.arange(x1, x2 + 1)
        xs, ys = np.meshgrid(xs, ys)

        res = self.kernel_profile_epanechnikov(
            ((cx - xs) * kernel_size_width) ** 2 + ((cy - ys) * kernel_size_height) ** 2)

        kernel_weight[ys, xs] = res

        max_val = np.max(kernel_weight)
        fg_prior = kernel_weight / max_val
        fg_prior = np.clip(fg_prior, a_min=0.5, a_max=0.9)

        return fg_prior

    def kernel_profile_epanechnikov(self, x):
        res = np.zeros_like(x)
        res[np.where(x <= 1)] = 2 / 3.14 * (1 - x[x <= 1])
        return res

    def pad_image(self, image, target_size):
        iw, ih = image.size
        w, h = target_size
        scale = 1

        # 保证长或宽，至少一个符合目标图像的尺寸
        nw = int(iw * scale)
        nh = int(ih * scale)

        image = image.resize((nw, nh), Image.BICUBIC)  # 缩小图像
        if self.need_debug_image:
            image.show()
        new_image = Image.new('RGB', target_size, (0, 0, 0))  # 生成黑色图像

        # 为整数除法，计算图像的位置
        new_image.paste(image, ((w - nw) // 2, (h - nh) // 2))  # 将图像填充为中间图像，两侧为灰色的样式
        if self.need_debug_image:
            new_image.show()

        return new_image
    # ↑↑↑ Modified by Y.Xiao
