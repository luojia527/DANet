from PIL import Image, ImageOps


img = Image.open('/media/test/Data/Dev_linux/Python3/pytracking-study/pytracking/test/VanGogh_1888_CafeTerraceAtNight.jpg')
img.show()

top_pad = 50
bottom_pad = 80
left_pad = 100
right_pad = 160

padding = (left_pad, top_pad, right_pad, bottom_pad)
img2 = ImageOps.expand(img, padding)
img2.show()
