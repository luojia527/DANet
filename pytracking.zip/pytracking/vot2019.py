import os
import sys
import argparse
import importlib
import numpy as np
import cv2

from toolkit.datasets import DatasetFactory
from toolkit.utils.region import vot_overlap, vot_float2str
# import VOT.vot as vot

env_path = os.path.join(os.path.dirname(__file__), '..')
if env_path not in sys.path:
    sys.path.append(env_path)

dataset = DatasetFactory.create_dataset(name='VOT2019',
                                       	dataset_root='/home/ubuntu/user_space/vot2019/',
                                        load_img=False)

tracker_param = 'default_vot' # parameter file

runs = 0 # run id

def get_parameters():
    param_module = importlib.import_module('pytracking.parameter.atom.{}'.format(tracker_param))
    params = param_module.parameters()

    return params

def convert_vot_anno_to_rect(vot_anno, type):
    if len(vot_anno) == 4:
        return vot_anno

    if type == 'union':
        x1 = min(vot_anno[0::2])
        x2 = max(vot_anno[0::2])
        y1 = min(vot_anno[1::2])
        y2 = max(vot_anno[1::2])
        return [x1, y1, x2 - x1, y2 - y1]
    elif type == 'preserve_area':
        if len(vot_anno) != 8:
            raise ValueError

        vot_anno = np.array(vot_anno)
        cx = np.mean(vot_anno[0::2])
        cy = np.mean(vot_anno[1::2])

        x1 = min(vot_anno[0::2])
        x2 = max(vot_anno[0::2])
        y1 = min(vot_anno[1::2])
        y2 = max(vot_anno[1::2])

        A1 = np.linalg.norm(vot_anno[0:2] - vot_anno[2: 4]) * np.linalg.norm(vot_anno[2: 4] - vot_anno[4:6])
        A2 = (x2 - x1) * (y2 - y1)
        s = np.sqrt(A1 / A2)
        w = s * (x2 - x1) + 1
        h = s * (y2 - y1) + 1

        x = cx - 0.5*w
        y = cy - 0.5*h
        return [x, y, w, h]
    else:
        raise ValueError

def main():
    # get parameters
    params = get_parameters()
    params.debug = 0
    params.tracker_name = 'ATOM'
    params.param_name = tracker_param
    params.visdom_info = None
    params.run_id = 0

    # initialize tracker
    tracker_module = importlib.import_module('pytracking.tracker.atom')
    tracker_class = tracker_module.get_tracker_class()
    tracker = tracker_class(params)

    total_lost = 0
    for v_idx, video in enumerate(dataset):
        # print(v_idx, video.name)
        frame_counter = 0
        lost_number = 0
        toc = 0
        pred_bboxes = []
        for idx, (img, gt_bbox) in enumerate(video):
            if len(gt_bbox) == 4:
                gt_bbox = [gt_bbox[0], gt_bbox[1],
                gt_bbox[0], gt_bbox[1]+gt_bbox[3]-1,
                gt_bbox[0]+gt_bbox[2]-1,gt_bbox[1]+gt_bbox[3]-1,
                gt_bbox[0]+gt_bbox[2]-1,gt_bbox[1]]
            tic = cv2.getTickCount()
            if idx == frame_counter:
                # init your tracker here
                pred_bboxes.append(1)

                # print('Initializing tracker...')
                tracker.initialize_features()
                tracker.initialize(img,{'init_bbox':convert_vot_anno_to_rect(gt_bbox, tracker.params.vot_anno_conversion_type)})
                pred_bbox = convert_vot_anno_to_rect(gt_bbox, tracker.params.vot_anno_conversion_type)
                # print('Tracking...')
                
            elif idx > frame_counter:
                # get tracking result here
                state = tracker.track(img)['target_bbox']
                pred_bbox = state#vot.Rectangle(state[0], state[1], state[2], state[3])
                overlap = vot_overlap(pred_bbox, gt_bbox, (img.shape[1], img.shape[0]))
                if overlap > 0: 
                # continue tracking
                    pred_bboxes.append(pred_bbox)
                else: 
                # lost target, restart
                    pred_bboxes.append(2)
                    frame_counter = idx + 5
                    lost_number+=1
                    # print('Tracking failed. Restarting...')
            else:
                pred_bboxes.append(0)
            toc += cv2.getTickCount() - tic
            # if idx == 0:
            #     cv2.destroyAllWindows()
            # if idx>frame_counter:
            #     cv2.polylines(img, [np.array(gt_bbox, np.int).reshape((-1,1,2))], True, (0,255,0),3)
            #     bbox = list(map(int, pred_bbox))
            #     cv2.rectangle(img, (bbox[0], bbox[1]),(bbox[0]+bbox[2],bbox[1]+bbox[3]),(0,255,255),3)
            #     cv2.putText(img,str(idx),(40,40),cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
            #     cv2.putText(img, str(lost_number), (40,80), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255),2)
            #     cv2.imshow(video.name,img)
            #     cv2.waitKey(1)
        toc /= cv2.getTickFrequency()
        # save results
        video_path = os.path.join('results', tracker_param + '_' + '{:0>3d}'.format(runs), 'DANet', 'baseline', video.name)
        if not os.path.isdir(video_path):
            os.makedirs(video_path)
        result_path = os.path.join(video_path, '{}_001.txt'.format(video.name))
        with open(result_path, 'w') as f:
            for x in pred_bboxes:
                if isinstance(x,int):
                    f.write("{:d}\n".format(x))
                else:
                    f.write(','.join([vot_float2str("%.4f", i) for i in x]) + '\n')
        print('({:3d}) Video: {:12s} Time: {:4.1f}s Speed: {:3.1f}fps Lost: {:d}'.format(v_idx+1, video.name, toc, idx/toc, lost_number))
        total_lost += lost_number
    print("DANet total lost:", total_lost)



if __name__ == '__main__':
    main()