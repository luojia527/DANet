from collections import OrderedDict

opts_act = OrderedDict()
opts_act['use_gpu'] = True

opts_act['model_path'] = './tracker/models/critic.pth'
opts_act['actor_path'] = './tracker/models/Actor250000.npy'


opts_act['img_size'] = 107  # default 107
opts_act['padding'] = 16  # default 16

opts_act['batch_pos'] = 32
opts_act['batch_neg'] = 96
opts_act['batch_neg_cand'] = 1024
opts_act['batch_test'] = 256

opts_act['n_samples'] = 256
opts_act['trans_f'] = 0.6
opts_act['scale_f'] = 1.05
opts_act['trans_f_expand'] = 1.2

opts_act['n_bbreg'] = 1000
opts_act['overlap_bbreg'] = [0.6, 1]
opts_act['scale_bbreg'] = [1, 2]

opts_act['lr_init'] = 0.0001
opts_act['maxiter_init'] = 30  # default is 30
opts_act['n_pos_init'] = 500   # default is 500
opts_act['n_neg_init'] = 5000
opts_act['overlap_pos_init'] = [0.7, 1]
opts_act['overlap_neg_init'] = [0, 0.5]

opts_act['lr_update'] = 0.0002   # default is 0.0002
opts_act['maxiter_update'] = 15   # default is 15
opts_act['n_pos_update'] = 50
opts_act['n_neg_update'] = 200
opts_act['overlap_pos_update'] = [0.7, 1]
opts_act['overlap_neg_update'] = [0, 0.3]

opts_act['success_thr'] = 0  # default 0
opts_act['n_frames_short'] = 20
opts_act['n_frames_long'] = 100
opts_act['long_interval'] = 10

opts_act['w_decay'] = 0.0005
opts_act['momentum'] = 0.9
opts_act['grad_clip'] = 10
opts_act['lr_mult'] = {'fc6':10}
opts_act['ft_layers'] = ['fc']
opts_act['show_train'] = 0
