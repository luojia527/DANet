from PIL import Image, ImageFilter

img = Image.open('/media/test/Data/Dev_linux/Python3/pytracking-study/pytracking/test/test.jpg')

img2 = img.filter(ImageFilter.BLUR)
img2.show()
img2.save('/media/test/Data/Dev_linux/Python3/pytracking-study/pytracking/test/img2.jpg', quality=100)

img3 = img.filter(ImageFilter.GaussianBlur(10))
img3.show()
img3.save('/media/test/Data/Dev_linux/Python3/pytracking-study/pytracking/test/img3.jpg', quality=100)

img4 = img.filter(ImageFilter.BoxBlur(10))
img4.show()
img4.save('/media/test/Data/Dev_linux/Python3/pytracking-study/pytracking/test/img4.jpg', quality=100)
