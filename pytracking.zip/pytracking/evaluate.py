import os
import sys
import time
import argparse
import functools
import numpy as np

from glob import glob
from tqdm import tqdm
from multiprocessing import Pool
from pysot.datasets import OTBDataset, UAVDataset, LaSOTDataset, VOTDataset, NFSDataset, VOTLTDataset
from pysot.evaluation import OPEBenchmark, AccuracyRobustnessBenchmark, EAOBenchmark, F1Benchmark
from pysot.visualization import draw_success_precision, draw_eao, draw_f1

tracker_dir = "/home/ubuntu/user_space/dev/pytracking-study/pytracking/results/default_013/"
trackers = ['ART']
root = "/home/ubuntu/user_space/vot2019-pysot/"
num = 1 # number of processes
show_video_level = True

dataset = VOTDataset('VOT2019', root)
dataset.set_tracker(tracker_dir, trackers)
ar_benchmark = AccuracyRobustnessBenchmark(dataset)
ar_result = {}
with Pool(processes=num) as pool:
    for ret in tqdm(pool.imap_unordered(ar_benchmark.eval,
        trackers), desc='eval ar', total=len(trackers), ncols=100):
        ar_result.update(ret)
# benchmark.show_result(ar_result)

benchmark = EAOBenchmark(dataset)
eao_result = {}
with Pool(processes=num) as pool:
    for ret in tqdm(pool.imap_unordered(benchmark.eval,
        trackers), desc='eval eao', total=len(trackers), ncols=100):
        eao_result.update(ret)
# benchmark.show_result(eao_result)
ar_benchmark.show_result(ar_result, eao_result,
        show_video_level=show_video_level)

result = ar_result
videos = list(result['ART']['overlaps'].keys())
for video in videos:
    for tracker_name in result.keys():
        overlaps = result[tracker_name]['overlaps'][video]
        accuracy = np.nanmean(overlaps)
        failures = result[tracker_name]['failures'][video]
        lost_number = np.mean(failures)

        accuracy_str = "{:.3f}".format(accuracy)

        lost_num_str = "{:.0f}".format(lost_number)

        os.rename(os.path.join(tracker_dir, 'ART', 'baseline', video, video + '_001.txt'), \
            os.path.join(tracker_dir, 'ART', 'baseline', video, video + '_001_' + accuracy_str + '_' + lost_num_str + '.txt'))
